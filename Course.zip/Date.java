public class Date
{
    //fields
    private int Year;
    private int Month;
    private int Day;
    //function
    //constructor
    public Date()
    {
        Year=1300;
        Month=1;
        Day=1;
    }
    public Date(int y,int m,int d)
    {
//        Year=y;
//       Month=m;
//        Day=d;
        setYear(y);
        setMonth(m);
        setDay(d);
    }

    //getter and setter
    public int getYear()
    {
        return Year;
    }
    public void setYear(int y)
    {
        if(y>0)
            Year=y;
        else
            Year=1;
    }
    public int getMonth()
    {
        return Month;
    }
    public void setMonth(int month)
    {
        if(month>0 && month<13)
            Month = month;
        else
            Month=1;
    }
    public int getDay()
    {
        return Day;
    }
    public void setDay(int day)
    {
        if(day>0 && day<32)
            Day = day;
        else
            Day=1;
    }
    //other
    public void print()
    {
        System.out.println(Year +"/"+ Month+"/"+Day);
    }
}
