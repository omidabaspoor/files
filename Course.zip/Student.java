public class Student
{
    //10
    private String Firstname;
    private String Lastname;
    private int Id;
    private double Avg;
    private String Fathername;
    private String Mothername;
    private String Adress;
    private long Codemeli;
    private long Phonenumr;
    private String Nationality;
    private String City;
    private String Religion;
    private long Homenum;
    private Date Bd;
    public Student(int id,String fname,String lname)
    {
        setId(id);
        setFirstname(fname);
        setLastname(lname);
        Avg=0;
        Bd=null;
    }
    public Student(int id,String fname,String lname,Date bd)
    {
        setId(id);
        setFirstname(fname);
        setLastname(lname);
        setBd(bd);
        Avg=0;
    }
    public Student(String fathername,String mothername,long phonenumr,long homenum)
    {
        setFathername(fathername);
        setMothername(mothername);
        setPhonenumr(phonenumr);
        setHomenum(homenum);
    }
    public Student()
    {
        Codemeli= 928732312L;
    }
    public Student(String city,String nationality,String religion,String adress)
    {
        setCity(city);
        setNationality(nationality);
        setReligion(religion);
        setAdress(adress);
    }
    public String getFirstname()
    {
        return Firstname;
    }
    public void setFirstname(String firstname)
    {
        Firstname = firstname;
    }
    public String getLastname()
    {
        return Lastname;
    }
    public void setLastname(String lastname)
    {
        Lastname = lastname;
    }
    public int getId()
    {
        return Id;
    }
    public void setId(int id)
    {
        if(id>0)
            Id = id;
        else
            id=1;
    }
    public double getAvg()
    {
        return Avg;
    }
    public String getFathername()
    {
        return Fathername;
    }
    public void setFathername(String fathername)
    {
        Fathername = fathername;
    }
    public String getMothername()
    {
        return Mothername;
    }
    public void setMothername(String mothername)
    {
        Mothername = mothername;
    }
    public String getAdress()
    {
        return Adress;
    }
    public void setAdress(String adress)
    {
        Adress= adress;
    }
    public long getCodemeli()
    {
        return Codemeli;
    }
    public long getPhonenumr()
    {
        return Phonenumr;
    }
    public void setPhonenumr(long phonenumr)
    {
        Phonenumr = phonenumr;
    }
    public String getNationality()
    {
        return Nationality;
    }
    public void setNationality(String nationality)
    {
        Nationality = nationality;
    }
    public String getCity()
    {
        return City;
    }
    public void setCity(String city)
    {
        City = city;
    }
    public String getReligion()
    {
        return Religion;
    }
    public void setReligion(String religion)
    {
        Religion = religion;
    }
    public long getHomenum()
    {
        return Homenum;
    }
    public void setHomenum(long homenum)
    {
        Homenum = homenum;
    }
    public Date getBd()
    {
        return Bd;
    }
    public void setBd(Date bd)
    {
        Bd = bd;
    }

    public void print()
    {
        System.out.println(Firstname);
        System.out.println(Lastname);
        System.out.println(Id);
        System.out.println(Avg);
        System.out.println(Fathername);
        System.out.println(Mothername);
        System.out.println(Adress);
        System.out.println(Codemeli);
        System.out.println(Phonenumr);
        System.out.println(Nationality);
        System.out.println(City);
        System.out.println(Religion);
        System.out.println(Homenum);
        Bd.print();
    }
    //computeavg

}
