import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
//        variables
        int a=22;
        double c=1.23;
        float d1=1.28f;
        float b=1.25f;
        long w=12345671234l;
        byte d=-45;
        short e=76;
        int a1=-65;
        long w1=-176543378l;
        float b1=5.876f;
        double c1=8.87;
        boolean g=true;
        char m='s';
        String o="sareh";

//        print
        System.out.print(d1);
        System.out.println(a);
        System.out.println(c);
        System.out.println("Hi");
        System.out.println("سلام");
        System.out.println('a');
        System.out.println("hi"+a);
        //concatenation
//        Array 1D
//        int[] anArray;
//        int anArray[];

//        C++
//        int *a;
//        a=new int[10];
        int[] anArray;
        anArray = new int[10];
        anArray[0] =100;
        anArray[1] =100;
        anArray[2] =100;
        System.out.println(anArray[0]);

        int[] anArray2 = {100,200,300,400,500,600,700,800,900,1000};
        System.out.println(anArray2.length);

//        Array 2D
//        int a[5][10];//C++
        int[][] anArray3 = new int[5][10];

        int[][] anArray4 = new int[5][];
        anArray4[0] = new int[10];
        anArray4[1] = new int[5];
        anArray4[2] = new int[7];

//        input
        Scanner sc= new Scanner(System.in);
        a=sc.nextInt();
        d1=sc.nextFloat();
        c=sc.nextDouble();
        b=sc.nextFloat();
        w=sc.nextLong();
        d=sc.nextByte();
        e=sc.nextShort();
        a1=sc.nextInt();
        w1=sc.nextLong();
        b1=sc.nextFloat();
        c1=sc.nextDouble();
        g=sc.nextBoolean();
        m=sc.next().charAt(0);
        o=sc.next();
        System.out.println( a+b);
        System.out.println( a*b);
        System.out.println( "hi"+a);
        System.out.println("hello"+ "hi");

//        if
//        if(10)//false
//            System.out.print(-a);
        if (a>10)
            System.out.println(a+10);

        if (a>10)
            System.out.println(a+10);
        else
            System.out.println(-a);

//        switch
        switch(a)
        {
            case 1:
                System.out.print('1');
                break;
            case 2:
                System.out.print('2');
                break;
            case 3:
                System.out.print("hi");
        }

//        while
        int count = 1;
        while(count<11){
            System.out.println("Count is: " + count);
            count++;
        }


        while(true)
        {
            a=sc.nextInt();
            if(a<0)
                break;
        }

//        for
        int n;
        n=sc.nextInt();
        int [] f=new int [5];
//        read
        for( int i=0; i<5; i++)
            f[i]=sc.nextInt();
//        print
//        1
        for(int i=0; i<5; i++)
            System.out.println(f[i]);
//2
        for(int i=0; i<f.length; i++)
            System.out.println(f[i]);
//3
        for( int h: f)
            System.out.println(h);
        int min=f[0];
        for(int i=0;i<f.length;i++)
            if(f[i]<min)
                min=f[i];
        System.out.println("min is:"+min);
        int max=f[0];
        for(int i=0;i<f.length;i++)
            if(f[i]>max)
                max=f[i];
        System.out.println("max is:"+max);
        int sum=0;
        for(int i=0;i<f.length;i++)
            sum=sum+f[i];
        System.out.println("sum is:"+sum);
        double avg=(double) sum/f.length;
        System.out.println("avg is:"+avg);
        int zarb=1;
        for(int i=0;i<f.length;i++)
            zarb=zarb*f[i];
        System.out.println("mul is:"+zarb);
        int x;
        x=sc.nextInt();
        boolean k= false;
        for(int i=0;i<f.length;i++)
        {
            if(f[i]==x)
            {
                k=true;
                break;
            }
        }
        if(k==true)
            System.out.println("found");
        else
            System.out.println("not found");

        //min,max,sum,avg,search,mul,imax,imin
        System.out.println(min(f));
        System.out.println(max(f));
        System.out.println(sum(f));
        System.out.println(avg(f));
        System.out.println(search(f,x) ? "not found" : "found it");
        System.out.println(mul(f));
        System.out.println(imax(f));
        System.out.println(imin(f));

        //function overloading
        System.out.println(sum(2,3));
        System.out.println(sum(2.5f,3));
        System.out.println(sum(2,3,4));
        System.out.println(sum(2.5f,3.5f));

        Date j=new Date();
        Date y;
        y=new Date();
        j.print();
        j.setYear(1405);
        System.out.println(j.getYear());
        j.setMonth(7);
        System.out.println(j.getMonth());
        j.setDay(22);
        System.out.println(j.getDay());
        j.print();
        Date z;
        z=new Date(1405,3,30);
        z.print();
        Date q=new Date(1405,3,4);
        q.print();
        Student s=new Student(567,"sareh","ahmadi");
        System.out.println(s.getFirstname());
        System.out.println(s.getLastname());
        System.out.println(s.getId());
        System.out.println(s.getAvg());
        System.out.println(s.getFathername());
        System.out.println(s.getMothername());
        System.out.println(s.getAdress());
        System.out.println(s.getCodemeli());
        System.out.println(s.getPhonenumr());
        System.out.println(s.getNationality());
        System.out.println(s.getCity());
        System.out.println(s.getReligion());
        System.out.println(s.getHomenum());
        System.out.println(s.getBd());
        Student n0=new Student(567,"sareh","ahmadi",q);
        n0.print();
        s.setBd(q);
        Student m0=new Student("ali","maryam",9156785438l,37546723l);
        m0.setBd(q);
        Student m1=new Student();
        m1.print();
        Student m2=new Student("mashhad","persian","islam","ebadi");
        m2.print();
        Rectangle v1=new Rectangle(22,15);
        v1.print();
        System.out.println(v1.getTool());
        System.out.println(v1.getArz());
        System.out.println(v1.getColor());
        System.out.println(v1.getXpoint());
        System.out.println(v1.getYpoint());
        Rectangle v2=new Rectangle("blue",8.4,9.6);
        v2.print();
        Course g1=new Course("math","haghighi","sunday");
        g1.print();
        System.out.println(g1.getName());
        System.out.println(g1.getClasscode());
        System.out.println(g1.getTeachername());
        System.out.println(g1.getVahed());
        System.out.println(g1.getZarfiat());
        System.out.println(g1.getNomreh());
        System.out.println(g1.getTime());
        System.out.println(g1.getNameday());
        System.out.println(g1.getPrice());
        System.out.println(g1.getTerm());
        Course g2=new Course(4,78.65);
        g2.print();
        Course g3=new Course(56,17,15);
        g3.print();
    }
    public static int min(int []a)
    {
        int m=a[0];
//        for(int i=0;i<a.length;i++)
//            if(a[i]<m)
//                m=a[i];
        for(int b:a)
            if(b<m)
                m=b;
        return 0;
    }
    public static int max(int []a)
    {
        int m=a[0];
        for(int i=0;i<a.length;i++)
            if(a[i]>m)
                m=a[i];
        return 0;
    }
    public static int sum(int []a)
    {
        int sum=0;
        for(int i=0;i<a.length;i++)
            sum=sum+a[i];
        return sum;
    }
    public static float avg(int []a)
    {
        int sum=0;
        float avg=0;
        for(int i=0;i<a.length;i++)
            sum=sum+a[i];
        avg=sum/a.length;
        return avg;
    }
    public static boolean search(int []a,int x)
    {
        for(int i=0;i<a.length;i++)
            if(a[i]==x)
                return true;
        return false;
    }
    public static int mul(int []a)
    {
        int mul=1;
        for(int i=0;i<a.length;i++)
            mul=mul*a[i];
        return mul;
    }
    public static int imax(int []a)
    {
        int imax=0;
        int max=a[0];
        for(int i=0;i<a.length;i++)
            if(a[i]>max)
            {
                max = a[i];
                imax = i;
            }
        return imax;
    }
    public static int imin(int []a)
    {
        int imin=0;
        int min=a[0];
        for(int i=0;i<a.length;i++)
            if(a[i]<min)
            {
                min = a[i];
                imin = i;
            }
        return imin;
    }

 //function overloading
    public static int sum(int a,int b)
    {
        return a+b;
    }
    public static int sum(int a,int b,int c)
    {
        return a+b+c;
    }
    public static float sum(float a,float b)
    {
        return a+b;
    }
}
