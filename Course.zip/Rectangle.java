public class Rectangle
{
    //5
    private double Tool;
    private double Arz;
    private String Color;
    private double Xpoint;
    private double Ypoint;

    public Rectangle(double tool,double arz)
    {
        setTool(tool);
        setArz(arz);
    }
    public Rectangle(String color,double xpoint,double ypoint)
    {
        setColor(color);
        setXpoint(xpoint);
        setYpoint(ypoint);
    }

    public double getTool()
    {
        return Tool;
    }
    public void setTool(double tool)
    {
        if(tool>0)
            Tool = tool;
        else
            tool=1;
    }
    public double getArz()
    {
        return Arz;
    }
    public void setArz(double arz)
    {
        if(arz>0)
            Arz = arz;
        else
            arz=1;
    }
    public String getColor()
    {
        return Color;
    }
    public void setColor(String color)
    {
        Color = color;
    }
    public double getXpoint()
    {
        return Xpoint;
    }
    public void setXpoint(double xpoint)
    {
        Xpoint = xpoint;
    }
    public double getYpoint()
    {
        return Ypoint;
    }
    public void setYpoint(double ypoint)
    {
        Ypoint = ypoint;
    }
    public void print()
    {
        System.out.println(Tool);
        System.out.println(Arz);
        System.out.println(Color);
        System.out.println(Xpoint);
        System.out.println(Ypoint);
    }
}
