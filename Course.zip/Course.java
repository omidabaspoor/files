public class Course
{
    //10
    private String Name;
    private long Classcode;
    private String Teachername;
    private int Vahed;
    private int Zarfiat;
    private int Nomreh;
    private int Time;
    private String Nameday;
    private double Price;
    private int Term;

    public Course(String name,String teachername,String nameday)
    {
        setName(name);
        setTeachername(teachername);
        setNameday(nameday);
    }
    public Course(int term,double price)
    {
        setTerm(term);
        setPrice(price);
        Classcode=65476548L;
        Vahed=2;
    }
    public Course(int zarfiat,int time ,int nomreh)
    {
        setZarfiat(zarfiat);
        setTime(time);
        setNomreh(nomreh);
    }

    public String getName()
    {
        return Name;
    }
    public void setName(String name)
    {
        Name = name;
    }
    public long getClasscode()
    {
        return Classcode;
    }
    public String getTeachername()
    {
        return Teachername;
    }
    public void setTeachername(String teachername)
    {
        Teachername = teachername;
    }
    public int getVahed()
    {
        return Vahed;
    }
    public int getZarfiat()
    {
        return Zarfiat;
    }
    public void setZarfiat(int zarfiat)
    {
        Zarfiat = zarfiat;
    }
    public int getNomreh()
    {
        return Nomreh;
    }
    public void setNomreh(int nomreh)
    {
        Nomreh = nomreh;
    }
    public int getTime()
    {
        return Time;
    }
    public void setTime(int time)
    {
        Time = time;
    }
    public String getNameday()
    {
        return Nameday;
    }
    public void setNameday(String nameday)
    {
        Nameday = nameday;
    }
    public double getPrice()
    {
        return Price;
    }
    public void setPrice(double price)
    {
        Price = price;
    }
    public int getTerm()
    {
        return Term;
    }
    public void setTerm(int term)
    {
        Term = term;
    }
    public void print()
    {
        System.out.println(Name);
        System.out.println(Classcode);
        System.out.println(Teachername);
        System.out.println(Vahed);
        System.out.println(Zarfiat);
        System.out.println(Nomreh);
        System.out.println(Time);
        System.out.println(Nameday);
        System.out.println(Price);
        System.out.println(Term);
    }
}
