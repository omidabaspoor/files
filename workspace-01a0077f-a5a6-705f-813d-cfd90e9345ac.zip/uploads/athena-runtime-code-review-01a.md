# بازبینی مستقل کد Athena Runtime PoC 01A

**ZIP SHA-256:** `7860136ae8b7cd8418b265304cf138f025a8b87506a4b603b758cc6055f51fbf`  
**وضعیت Hash:** مطابق مقدار اعلام‌شده  
**تعداد فایل:** ۲۲  
**نتیجه تست مستقل پس از نصب dependency توسعه:** ۲۶ Pass

## حکم

**PASS مفهومی، اما Gate کدنویسی بعدی هنوز باز نمی‌شود.**

هسته نشان می‌دهد Fail-Closed Tool Broker عملی است. با این حال چهار مسیر دورزدن Invariant در خود کد وجود دارد که قبل از PostgreSQL و API باید اصلاح شوند.

---

# یافته‌های مهم

## F01 — تغییر مستقیم State در Run

**شدت:** P1 برای هسته Domain

`Run.state` عمومی و قابل تغییر است:

```python
run.state = RunState.COMPLETED
```

این تغییر State Machine و Event را دور می‌زند.

### اصلاح لازم

- State داخلی و Private باشد.
- فقط Property خواندنی ارائه شود.
- تغییر فقط از `transition()` ممکن باشد.

---

## F02 — تغییر مستقیم Event List

**شدت:** P1

`Run.events` یک List عمومی است. Caller می‌تواند Event جعلی اضافه یا حذف کند.

### اصلاح لازم

- Eventها در Collection خصوصی نگه‌داری شوند.
- خروجی فقط Tuple یا Read-only Snapshot باشد.
- Sequence از State داخلی ساخته شود.

---

## F03 — دورزدن Plan Validation

**شدت:** P1

`Plan.validate_for()` بررسی Scope و Cycle را انجام می‌دهد؛ اما Caller می‌تواند مستقیم این کار را انجام دهد:

```python
Plan(steps=(PlanStep(operation="outside", ...),))
```

در این حالت Scope، Cycle و `max_steps` بررسی نمی‌شوند.

### اصلاح لازم

دو نوع جدا ساخته شود:

- `PlanProposal`: خروجی غیرقابل اعتماد Planner
- `ValidatedPlan`: فقط خروجی `PlanValidator`

Executor فقط `ValidatedPlan` بپذیرد. ساخت مستقیم ValidatedPlan از خارج Module ممکن نباشد یا دوباره در مرز اجرا Validate شود.

---

## F04 — ToolRequest و Arguments قابل تغییر هستند

**شدت:** P1 / TOCTOU

`ToolRequest` Frozen نیست و `arguments` یک Dict مشترک است. Authorizer می‌تواند Arguments را پس از دریافت تغییر دهد و Handler مقدار تغییرکرده را اجرا کند.

این رفتار در بازبینی مستقل بازتولید شد.

### اصلاح لازم

- Arguments پیش از Authorization به JSON استاندارد و Strict تبدیل شوند.
- `NaN` و مقدار غیر JSON رد شوند.
- `args_digest` از Snapshot ساخته شود.
- Authorizer فقط Metadata و Digest غیرقابل تغییر را ببیند.
- Handler بعد از ALLOW یک Copy تازه از Snapshot دریافت کند.
- Tool Schema مخصوص هر Operation باشد.

---

## F05 — Idempotency تعارض Arguments را تشخیص نمی‌دهد

**شدت:** P1

Key فعلی شامل Arguments نیست. اگر همان `tool_call_id` با Arguments متفاوت ارسال شود، Outcome قبلی Replay می‌شود.

این رفتار Side Effect دوم ایجاد نمی‌کند، اما نتیجه‌ی اشتباه را به Request جدید نسبت می‌دهد.

### اصلاح لازم

- Fingerprint شامل `args_digest` و Policy Version باشد.
- استفاده دوباره از Key با Fingerprint متفاوت برابر `IDEMPOTENCY_CONFLICT` باشد.
- Conflict هرگز Replay یا Execute نشود.

---

## F06 — CancelledError بلعیده می‌شود

**شدت:** P1 برای Stop و Shutdown

`authorize_fail_closed`، `asyncio.CancelledError` را به DENY تبدیل می‌کند. Cancel شدن Task والد باید Propagate شود تا Stop و Shutdown درست کار کنند.

### اصلاح لازم

- Timeout داخلی برابر DENY باشد.
- Exception معمولی برابر DENY باشد.
- Cancellation خارجی دوباره Raise شود.
- تست Caller Cancellation اضافه شود.

---

## F07 — Float برای Budget و Cost

**شدت:** P2، الزامی قبل از Ledger

`float` برای پول مناسب نیست.

### اصلاح لازم

- `max_cost_microunits: int`
- `estimated_cost_microunits: int`
- مقدار منفی رد شود.

---

## F08 — Clock سراسری و غیرقابل تزریق

**شدت:** P2

`datetime.now()` در Run، Policy و Approval مستقیم استفاده شده است.

### اصلاح لازم

- `Clock` Protocol
- `SystemClock`
- `FakeClock` برای تست
- تمام زمان‌ها UTC

---

## F09 — Schema عمومی Arguments کافی نیست

**شدت:** P1 پیش از Tool واقعی

فیلتر نام کلیدهای `prompt/code/script/...` مرز امنیت واقعی نیست. مقدار مخرب می‌تواند زیر کلید دیگری قرار گیرد.

### اصلاح لازم

هر Tool یک Pydantic Input Model با `extra="forbid"`، اندازه و دامنه‌ی دقیق داشته باشد. Generic Arguments فقط برای Transport است؛ اجرای Tool فقط پس از Validation مخصوص Tool انجام شود.

---

# نقاط قوت تأییدشده

- Permission Intersection صحیح و Fail-Closed است.
- Missing Scope برابر Empty Set است.
- Authorizer Exception و Timeout Side Effect ایجاد نمی‌کنند.
- Approval Scope را افزایش نمی‌دهد.
- Handler فقط پس از Authorization و Reservation اجرا می‌شود.
- Duplicate یکسان Side Effect دوم ایجاد نمی‌کند.
- Dynamic Plugin و Network وجود ندارد.
- Secret داخل ZIP دیده نشد.
- Manifest و Hash درست بودند.

---

# تست‌های تکمیلی لازم

1. Mutation مستقیم Run State رد شود.
2. Mutation Event Collection ممکن نباشد.
3. Plan مستقیم نتواند Validation را دور بزند.
4. Authorizer نتواند Arguments اجرایی را تغییر دهد.
5. Idempotency Key با Args متفاوت Conflict دهد.
6. External Cancellation Propagate شود.
7. Verifier False و Exception تست شوند.
8. Handler ثبت‌نشده تست شود.
9. Approval منقضی و Deny تست شوند.
10. Shared Broker در ۲۰ Run هم‌زمان تست شود.
11. JSON شامل NaN و Object غیرقابل Serialization رد شود.
12. Python 3.12 در CI اجرا شود.

## تصمیم Gate

قبل از اجرای Prompt مربوط به PostgreSQL یا FastAPI، یک مرحله Hardening با نام 01A.1 لازم است.

> هسته درست جهت‌گیری شده است؛ اما Invariant فقط وقتی معتبر است که Caller نتواند آن را با Constructor، Mutation یا Cancellation دور بزند.
