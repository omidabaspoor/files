import asyncio
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest

from athena_runtime.approvals import Approval, ApprovalStore
from athena_runtime.authorization import AuthorizationDecision
from athena_runtime.capsule import IntentCapsule
from athena_runtime.clocks import FakeClock
from athena_runtime.errors import IdempotencyConflict
from athena_runtime.idempotency import InMemoryIdempotencyStore
from athena_runtime.plans import (
    PlanExecutionBoundary,
    PlanProposal,
    PlanStepProposal,
    PlanValidator,
    ValidatedPlan,
)
from athena_runtime.policy import PolicyEngine
from athena_runtime.runs import Run, RunState
from athena_runtime.tools import (
    AuthorizationRequest,
    BrokerOutcomeStatus,
    CanaryInput,
    ToolBroker,
    ToolDefinition,
    ToolRequest,
    canary_definition,
)

NOW = datetime(2026, 1, 1, tzinfo=UTC)


@pytest.fixture(autouse=True)
def cleanup_temp_markers(tmp_path: Path) -> Iterator[None]:
    yield
    for marker in tmp_path.glob("marker-*.txt"):
        marker.unlink()


class Verifier:
    def __init__(self, result: bool = True, error: Exception | None = None) -> None:
        self.result = result
        self.error = error

    def verify(self, capsule: IntentCapsule) -> bool:
        if self.error:
            raise self.error
        return self.result


class Authorizer:
    def __init__(self, result: Any = AuthorizationDecision.ALLOW) -> None:
        self.result = result
        self.seen: AuthorizationRequest | None = None

    async def authorize(self, request: object) -> Any:
        assert isinstance(request, AuthorizationRequest)
        self.seen = request
        return self.result


def cap(clock: FakeClock, run_id: str = "r", **changes: object) -> IntentCapsule:
    data: dict[str, object] = {
        "run_id": run_id,
        "workspace_id": "w",
        "goal": "g",
        "requested_operations": {"allowed_canary"},
        "task_allowed_operations": {"allowed_canary"},
        "server_maximum_operations": {"allowed_canary"},
        "plan_scope_operations": {"allowed_canary"},
        "max_cost_microunits": 10,
        "max_steps": 3,
        "expires_at": clock.now() + timedelta(minutes=1),
        "nonce": "n",
        "policy_version": "v1",
    }
    data.update(changes)
    return IntentCapsule(**data)


def make_broker(
    tmp_path: Path,
    clock: FakeClock,
    authorizer: Authorizer,
    verifier: Verifier | None = None,
    approvals: ApprovalStore | None = None,
) -> ToolBroker:
    broker = ToolBroker(
        verifier or Verifier(),
        PolicyEngine({"v1"}, {"allowed_canary", "forbidden_canary"}, clock),
        authorizer,
        approvals or ApprovalStore(clock),
        InMemoryIdempotencyStore(),
        0.05,
    )
    broker.register(canary_definition("allowed_canary", tmp_path))
    broker.register(canary_definition("forbidden_canary", tmp_path))
    return broker


@pytest.mark.parametrize("attribute", ["state", "events"])
def test_h01_h02_run_internals_are_read_only(attribute: str) -> None:
    run = Run("r", clock=FakeClock(NOW))
    with pytest.raises(AttributeError):
        setattr(run, attribute, RunState.COMPLETED if attribute == "state" else ())
    assert isinstance(run.events, tuple)
    with pytest.raises(AttributeError):
        run.events.append("fake")  # type: ignore[attr-defined]


def test_h16_fake_clock_controls_run_and_policy_expiry() -> None:
    clock = FakeClock(NOW)
    run = Run("r", clock=clock)
    event = run.transition(RunState.VALIDATING)
    assert event.occurred_at == NOW
    capsule = cap(clock)
    policy = PolicyEngine({"v1"}, {"allowed_canary"}, clock)
    assert policy.effective_permissions(capsule)
    clock.advance(timedelta(minutes=2))
    assert not policy.effective_permissions(capsule)


def test_h03_plan_outside_scope_never_validates() -> None:
    clock = FakeClock(NOW)
    proposal = PlanProposal(
        steps=(
            PlanStepProposal(
                step_id="x",
                operation="forbidden_canary",
                arguments={},
                depends_on=(),
                estimated_cost_microunits=1,
            ),
        )
    )
    policy = PolicyEngine({"v1"}, {"allowed_canary"}, clock)
    validator = PlanValidator({"allowed_canary": CanaryInput}, policy)
    with pytest.raises(ValueError):
        validator.validate(proposal, cap(clock))


def test_h04_direct_validated_plan_cannot_cross_execution_boundary() -> None:
    clock = FakeClock(NOW)
    capsule = cap(clock)
    policy = PolicyEngine({"v1"}, {"allowed_canary"}, clock)
    boundary = PlanExecutionBoundary(policy)
    with pytest.raises(TypeError):
        ValidatedPlan((), "forged", object())
    with pytest.raises((TypeError, ValueError)):
        boundary.accept(object(), capsule)  # type: ignore[arg-type]

    proposal = PlanProposal(
        steps=(
            PlanStepProposal(
                step_id="x",
                operation="allowed_canary",
                arguments={},
                estimated_cost_microunits=1,
            ),
        )
    )
    valid = PlanValidator({"allowed_canary": CanaryInput}, policy).validate(proposal, capsule)
    assert boundary.accept(valid, capsule) == valid.steps
    object.__setattr__(valid, "_integrity_hash", "tampered")
    with pytest.raises(ValueError):
        boundary.accept(valid, capsule)


@pytest.mark.asyncio
async def test_h05_authorizer_cannot_mutate_handler_arguments(tmp_path: Path) -> None:
    clock = FakeClock(NOW)

    class MutatingAuthorizer(Authorizer):
        async def authorize(self, request: object) -> AuthorizationDecision:
            assert isinstance(request, AuthorizationRequest)
            with pytest.raises(AttributeError):
                request.operation = "forbidden_canary"  # type: ignore[misc]
            assert not hasattr(request, "arguments")
            return AuthorizationDecision.ALLOW

    seen: list[dict[str, Any]] = []

    async def handler(arguments: dict[str, Any]) -> dict[str, Any]:
        seen.append(arguments.copy())
        arguments["value"] = 999
        return {"ok": True}

    broker = make_broker(tmp_path, clock, MutatingAuthorizer())
    broker.register(ToolDefinition("allowed_canary", CanaryInput, handler))
    request = ToolRequest("c", "allowed_canary", {"value": 7})
    outcome = await broker.execute(cap(clock), request)
    assert outcome.status is BrokerOutcomeStatus.SUCCEEDED
    assert seen == [{"value": 7}]
    assert request.fresh_arguments() == {"value": 7}


@pytest.mark.asyncio
async def test_h06_same_key_different_arguments_conflicts(tmp_path: Path) -> None:
    clock = FakeClock(NOW)
    broker = make_broker(tmp_path, clock, Authorizer())
    first = await broker.execute(cap(clock), ToolRequest("c", "allowed_canary", {"value": 1}))
    second = await broker.execute(cap(clock), ToolRequest("c", "allowed_canary", {"value": 2}))
    assert first.status is BrokerOutcomeStatus.SUCCEEDED
    assert second.status is BrokerOutcomeStatus.IDEMPOTENCY_CONFLICT
    assert isinstance(second.error, IdempotencyConflict)
    assert len(list(tmp_path.glob("marker-*.txt"))) == 1


@pytest.mark.asyncio
async def test_h07_external_cancellation_propagates_without_handler(tmp_path: Path) -> None:
    clock = FakeClock(NOW)
    entered = asyncio.Event()

    class WaitingAuthorizer(Authorizer):
        async def authorize(self, request: object) -> AuthorizationDecision:
            entered.set()
            await asyncio.sleep(10)
            return AuthorizationDecision.ALLOW

    broker = make_broker(tmp_path, clock, WaitingAuthorizer())
    task = asyncio.create_task(broker.execute(cap(clock), ToolRequest("c", "allowed_canary", {})))
    await entered.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    assert not list(tmp_path.glob("marker-*.txt"))


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("verifier", "register"),
    [(Verifier(False), True), (Verifier(error=RuntimeError("bad")), True), (Verifier(), False)],
)
async def test_h08_h09_h10_verifier_and_registry_fail_closed(
    tmp_path: Path, verifier: Verifier, register: bool
) -> None:
    clock = FakeClock(NOW)
    broker = ToolBroker(
        verifier,
        PolicyEngine({"v1"}, {"allowed_canary"}, clock),
        Authorizer(),
        ApprovalStore(clock),
        InMemoryIdempotencyStore(),
        0.05,
    )
    if register:
        broker.register(canary_definition("allowed_canary", tmp_path))
    outcome = await broker.execute(cap(clock), ToolRequest("c", "allowed_canary", {}))
    assert outcome.status is BrokerOutcomeStatus.DENIED
    assert not list(tmp_path.glob("marker-*.txt"))


@pytest.mark.asyncio
@pytest.mark.parametrize("decision", ["once", "deny"])
async def test_h11_h12_expired_or_denied_approval(tmp_path: Path, decision: str) -> None:
    clock = FakeClock(NOW)
    store = ApprovalStore(clock)
    request = ToolRequest("c", "allowed_canary", {})
    await store.add(
        Approval(
            run_id="r",
            tool_call_id="c",
            operation="allowed_canary",
            args_digest=request.args_digest,
            expires_at=clock.now() - timedelta(seconds=1)
            if decision == "once"
            else clock.now() + timedelta(minutes=1),
            decision=decision,
        )
    )
    outcome = await make_broker(
        tmp_path, clock, Authorizer(AuthorizationDecision.REQUIRE_APPROVAL), approvals=store
    ).execute(cap(clock), request)
    assert outcome.status is BrokerOutcomeStatus.DENIED
    assert not list(tmp_path.glob("marker-*.txt"))


@pytest.mark.parametrize("value", [float("nan"), float("inf"), float("-inf")])
def test_h13_non_finite_json_rejected(value: float) -> None:
    with pytest.raises(ValueError):
        ToolRequest("c", "allowed_canary", {"value": value})


def test_h14_non_json_object_rejected() -> None:
    with pytest.raises((TypeError, ValueError)):
        ToolRequest("c", "allowed_canary", {"value": object()})


@pytest.mark.asyncio
async def test_h15_shared_broker_isolates_twenty_runs(tmp_path: Path) -> None:
    clock = FakeClock(NOW)
    broker = make_broker(tmp_path, clock, Authorizer())
    tasks = []
    for index in range(20):
        allowed = index % 2 == 0
        capsule = cap(
            clock,
            str(index),
            requested_operations={"allowed_canary" if allowed else "forbidden_canary"},
        )
        tasks.append(broker.execute(capsule, ToolRequest(str(index), "allowed_canary", {})))
    outcomes = await asyncio.gather(*tasks)
    assert sum(o.status is BrokerOutcomeStatus.SUCCEEDED for o in outcomes) == 10
    assert len(list(tmp_path.glob("marker-*.txt"))) == 10
