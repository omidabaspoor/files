from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from athena_runtime.capsule import IntentCapsule
from athena_runtime.errors import InvalidTransition
from athena_runtime.plans import PlanProposal, PlanStepProposal, PlanValidator
from athena_runtime.policy import PolicyEngine
from athena_runtime.runs import Run, RunState
from athena_runtime.tools import CanaryInput


def capsule(**changes: object) -> IntentCapsule:
    data = dict(
        run_id="r1",
        workspace_id="w1",
        goal="test",
        requested_operations={"allowed_canary"},
        task_allowed_operations={"allowed_canary"},
        server_maximum_operations={"allowed_canary"},
        plan_scope_operations={"allowed_canary"},
        max_cost_microunits=10,
        max_steps=3,
        expires_at=datetime.now(UTC) + timedelta(minutes=5),
        nonce="n",
        policy_version="v1",
    )
    data.update(changes)
    return IntentCapsule(**data)


def step(
    step_id: str,
    *,
    operation: str = "allowed_canary",
    arguments: dict[str, object] | None = None,
    depends_on: tuple[str, ...] = (),
    cost: int = 1,
) -> PlanStepProposal:
    return PlanStepProposal(
        step_id=step_id,
        operation=operation,
        arguments=arguments or {},
        depends_on=depends_on,
        estimated_cost_microunits=cost,
    )


def validate(steps: tuple[PlanStepProposal, ...], cap: IntentCapsule):
    policy = PolicyEngine({"v1"}, {"allowed_canary"})
    return PlanValidator({"allowed_canary": CanaryInput}, policy).validate(
        PlanProposal(steps=steps), cap
    )


def test_success_path_and_monotonic_events() -> None:
    run = Run("r")
    for state in [
        RunState.VALIDATING,
        RunState.QUEUED,
        RunState.RUNNING,
        RunState.QUALITY_CHECK,
        RunState.COMPLETED,
    ]:
        run.transition(state)
    assert [event.sequence for event in run.events] == [1, 2, 3, 4, 5]
    assert all(event.run_id == "r" and event.occurred_at.tzinfo == UTC for event in run.events)


@pytest.mark.parametrize(
    "path",
    [
        [RunState.VALIDATING, RunState.NEEDS_CLARIFICATION, RunState.VALIDATING],
        [RunState.VALIDATING, RunState.NEEDS_APPROVAL, RunState.QUEUED],
        [RunState.VALIDATING, RunState.QUEUED, RunState.STOPPED],
        [RunState.VALIDATING, RunState.EXPIRED],
    ],
)
def test_explicit_branches(path: list[RunState]) -> None:
    run = Run("r")
    for state in path:
        run.transition(state)
    assert run.state == path[-1]


def test_invalid_and_terminal_reactivation() -> None:
    with pytest.raises(InvalidTransition):
        Run("r").transition(RunState.RUNNING)
    run = Run("r")
    run.transition(RunState.VALIDATING)
    run.transition(RunState.EXPIRED)
    with pytest.raises(InvalidTransition):
        run.transition(RunState.RUNNING)


def test_capsule_is_deeply_immutable_and_validated() -> None:
    cap = capsule()
    assert isinstance(cap.requested_operations, frozenset)
    with pytest.raises(ValidationError):
        cap.goal = "changed"  # type: ignore[misc]
    with pytest.raises(ValidationError):
        capsule(run_id="")
    with pytest.raises(ValidationError):
        capsule(max_cost_microunits=-1)
    with pytest.raises(ValidationError):
        capsule(max_steps=0)
    with pytest.raises(ValidationError):
        capsule(max_steps=101)


def test_plan_validation_success_and_failures() -> None:
    cap = capsule(max_steps=2)
    plan = validate((step("a"), step("b", depends_on=("a",))), cap)
    assert len(plan.steps) == 2
    with pytest.raises(ValueError, match="unknown operation"):
        validate((step("a", operation="forbidden_canary"),), cap)
    with pytest.raises(ValueError, match="unknown dependency"):
        validate((step("a", depends_on=("b",)),), cap)
    with pytest.raises(ValueError, match="cycle"):
        validate((step("a", depends_on=("b",)), step("b", depends_on=("a",))), cap)
    with pytest.raises(ValueError, match="duplicate"):
        validate((step("a"), step("a")), cap)
    with pytest.raises(ValueError, match="arguments"):
        validate((step("a", arguments={"prompt": "not a canary input"}),), cap)
    with pytest.raises(ValueError, match="cost"):
        validate((step("a", cost=11),), cap)
    with pytest.raises(ValidationError):
        step("a", cost=-1)
