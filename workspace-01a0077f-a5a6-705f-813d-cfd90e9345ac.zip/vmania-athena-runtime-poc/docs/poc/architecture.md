# معماری PoC هسته Athena Runtime

## اجزا

- **Run aggregate**: گراف صریح Stateها را اعمال و برای هر Transition یک Event با `run_id`، شماره Sequence افزایشی، State مبدأ/مقصد و زمان UTC تولید می‌کند.
- **Intent Capsule**: مدل Frozen از Pydantic است. مجموعه‌های Operation به `frozenset` تبدیل می‌شوند و Validation مرزهای Budget، Expiry، شناسه‌ها و `max_steps` را اعمال می‌کند. `CapsuleVerifier` فقط Interface است و Crypto در این PoC ساخته نشده است.
- **Policy Engine**: Permission مؤثر را فقط با Intersection چهار Scope محاسبه می‌کند. Expiry، نسخه ناشناخته، مجموعه خالی یا Operation ناشناخته به مجموعه خالی منجر می‌شود.
- **Authorization Worker boundary**: Worker فقط Request را می‌بیند و هیچ Reference به Handler ندارد. اجرای async با `asyncio.wait_for` محدود می‌شود. Timeout، Exception، `None` و نوع نامعتبر همگی `DENY` هستند.
- **Approval Store**: Approval فقط `once` یا `deny` است؛ کلید آن Run، Tool Call، Operation و Digest canonical از Arguments را در بر دارد. مصرف `once` اتمیک و یک‌بارمصرف است.
- **Idempotency Store**: Interface رفتاری با Implementation حافظه‌ای و Lock async. کلید شامل Workspace، Run، Tool Call و Operation است. حالت‌های Reservation، In-progress و Replay را تفکیک می‌کند.
- **Tool Broker**: فقط دو نام Canary ثابت را می‌پذیرد و Discovery/Import پویا ندارد. Outcome موفق، ناموفق، درحال‌اجرا، Replay یا Denied را تولید می‌کند.
- **Plan Schema**: JSON-مانند و Frozen، با Stepهای محدود، سقف 4096 بایت برای Arguments، ممنوعیت کلیدهای Prompt/Code/Script/Command/Executable، کنترل Scope، Cycle، Duplicate و Dependency.

## Trust boundary

Capsule، Plan و Tool Request ورودی غیرقابل‌اعتماد محسوب می‌شوند. Verifier و Policy Engine در مرز قابل‌اعتماد Runtime هستند. Authorizer جدا از Handler است. Handler تنها پس از پایان موفق تمام کنترل‌های مجوز و Reservation قابل فراخوانی است. Temp Directory تست تنها Side-effect boundary این PoC است.

## جریان مجوز

1. Verify کردن Capsule؛ خطا یا مقدار غیر `True` برابر Deny.
2. محاسبه `requested ∩ task_allowed ∩ server_maximum ∩ plan_scope`.
3. اجرای Authorizer محدود به Timeout؛ فقط Enum معتبر پذیرفته می‌شود.
4. در `REQUIRE_APPROVAL`، مصرف Approval منقضی‌نشده و دقیقاً منطبق؛ Approval خارج Scope هیچ‌گاه به این مرحله نمی‌رسد.
5. بررسی Handler ثابت و سپس Reserve اتمیک Idempotency.
6. فقط `ALLOW` یا `REQUIRE_APPROVAL` با Approval مصرف‌شده Handler را اجرا می‌کند.
7. ثبت Outcome نهایی برای Replay؛ Handler failure نیز ثبت می‌شود تا Retry کور انجام نشود.

هیچ Side Effect پیش از اتمام Authorization و Reserve ایجاد نمی‌شود.

## State machine

مسیر اصلی:

`created → validating → queued → running → quality_check → completed`

شاخه‌های صریح شامل `needs_clarification`، `needs_approval` و Stateهای نهایی `completed`, `failed`, `stopped`, `expired`, `blocked` هستند. Stateهای نهایی Edge خروجی ندارند؛ بنابراین فعال‌سازی دوباره ممکن نیست. هر Edge غیرثبت‌شده `InvalidTransition` ایجاد می‌کند.

## دلیل Fail-Closed

هر ابهام به Deny تبدیل می‌شود: Verifier exception، Policy خالی/ناشناخته/منقضی، Operation ناشناخته، Authorizer exception/timeout/type نامعتبر، Approval نامنطبق، Handler ثبت‌نشده و وضعیت Idempotency درحال‌اجرا. هیچ Catch عمومی مسیر Allow نمی‌سازد. Coroutine مربوط به Timeout توسط `asyncio.wait_for` لغو می‌شود و Thread غیرقابل‌لغو وجود ندارد.
