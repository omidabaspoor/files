# vmania Athena Runtime PoC

A deliberately small, fail-closed domain and security kernel for Athena Runtime. This repository contains no API, database, network access, model adapter, worker, UI, dynamic plugins, or production tools.

## Scope proved

- Explicit run state machine and sequenced UTC domain events
- Frozen intent capsules with immutable operation sets
- Four-way permission intersection and deny-all policy failure behavior
- Cancellable async authorization with three decisions
- Fixed canary tool broker, one-time approvals, and atomic in-memory idempotency
- Bounded, acyclic, structured plan schema
- Security scenarios S01–S15, including 20 concurrent isolated runs

## Commands

```bash
python -m pip install -e '.[dev]'
pytest -q
ruff check .
python -m compileall -q src tests
```

Python 3.12+ is required. Runtime dependency: Pydantic 2. Development dependencies are pytest, pytest-asyncio, and Ruff.

See `docs/poc/architecture.md`, `docs/poc/decisions.md`, and `docs/poc/test-results.md`.
