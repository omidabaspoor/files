"""Fail-closed Athena Runtime domain/security proof of concept."""
