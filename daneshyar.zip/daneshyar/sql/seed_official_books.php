<?php
/**
 * اجرای CLI برای تزریق کتاب‌های رسمی آماده.
 * استفاده روی سرور:
 *   php sql/seed_official_books.php
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Forbidden');
}

require_once dirname(__DIR__) . '/includes/official_books.php';

$results = seed_official_books();
foreach ($results as $r) {
    $status = !empty($r['ok']) ? 'OK' : 'FAIL';
    echo '[' . $status . '] ' . ($r['title'] ?? 'book') . ' — ' . ($r['message'] ?? '') . PHP_EOL;
    if (!empty($r['book_id'])) echo '    book_id=' . $r['book_id'] . ' chunks=' . (int)($r['chunks'] ?? 0) . PHP_EOL;
}
