<?php
/**
 * ============================================================
 *  دانش‌یار - نصب/آپدیت امن دیتابیس
 * ------------------------------------------------------------
 *  هدف: install.php بتواند هم نصب اولیه انجام دهد، هم دیتابیس‌های
 *  موجود را بدون آسیب به اطلاعات قبلی به‌روزرسانی کند.
 *
 *  قانون‌ها:
 *  - هیچ DROP / TRUNCATE / DELETE عمومی انجام نمی‌شود.
 *  - فقط CREATE TABLE IF NOT EXISTS و ALTER ADD/MODIFY امن اجرا می‌شود.
 *  - INSERTهای پیش‌فرض با INSERT IGNORE انجام می‌شوند.
 * ============================================================
 */

if (!function_exists('dy_table_exists')) {
    function dy_table_exists(PDO $pdo, string $table): bool {
        try {
            $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
            $st->execute([$table]);
            return (int)$st->fetchColumn() > 0;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('dy_column_exists')) {
    function dy_column_exists(PDO $pdo, string $table, string $column): bool {
        try {
            $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
            $st->execute([$table, $column]);
            return (int)$st->fetchColumn() > 0;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('dy_index_exists')) {
    function dy_index_exists(PDO $pdo, string $table, string $index): bool {
        try {
            $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?");
            $st->execute([$table, $index]);
            return (int)$st->fetchColumn() > 0;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('dy_exec_safe')) {
    function dy_exec_safe(PDO $pdo, string $sql, array &$messages = [], string $okMessage = ''): bool {
        try {
            $pdo->exec($sql);
            if ($okMessage !== '') $messages[] = ['ok', $okMessage];
            return true;
        } catch (Throwable $e) {
            $messages[] = ['info', '• رد شد/قبلاً موجود بود: ' . $e->getMessage()];
            return false;
        }
    }
}

if (!function_exists('dy_add_column_if_missing')) {
    function dy_add_column_if_missing(PDO $pdo, string $table, string $column, string $definition, array &$messages = []): void {
        if (!dy_table_exists($pdo, $table)) return;
        if (dy_column_exists($pdo, $table, $column)) return;
        dy_exec_safe($pdo, "ALTER TABLE `$table` ADD COLUMN $definition", $messages, "✓ ستون `$table.$column` اضافه شد");
    }
}

if (!function_exists('dy_add_index_if_missing')) {
    function dy_add_index_if_missing(PDO $pdo, string $table, string $index, string $definition, array &$messages = []): void {
        if (!dy_table_exists($pdo, $table)) return;
        if (dy_index_exists($pdo, $table, $index)) return;
        dy_exec_safe($pdo, "ALTER TABLE `$table` ADD $definition", $messages, "✓ ایندکس `$table.$index` آماده شد");
    }
}

if (!function_exists('dy_run_base_install_sql_safely')) {
    function dy_run_base_install_sql_safely(PDO $pdo, string $adminHash, array &$messages = []): void {
        $installSqlPath = dirname(__DIR__) . '/sql/install.sql';
        if (!is_file($installSqlPath)) {
            $messages[] = ['err', 'فایل sql/install.sql پیدا نشد.'];
            return;
        }

        $sql = (string)file_get_contents($installSqlPath);
        $sql = preg_replace('/CREATE DATABASE.*?;/is', '', $sql, 1);
        $sql = preg_replace('/USE\s+`?\w+`?\s*;/i', '', $sql);
        $sql = str_replace('__ADMIN_HASH__', $adminHash, $sql);

        // install.sql فقط CREATE TABLE IF NOT EXISTS و INSERT IGNORE و چند UPDATE سازگار دارد؛
        // هیچ داده‌ای را پاک نمی‌کند.
        $pdo->exec($sql);
        $messages[] = ['ok', '✓ جداول پایه ساخته/بررسی شدند (بدون حذف اطلاعات قبلی)'];
    }
}

if (!function_exists('dy_sync_admin_from_env')) {
    /**
     * هماهنگ‌سازی ادمین با ADMIN_USER و ADMIN_PASS فایل env.
     * هیچ کاربری حذف نمی‌شود؛ فقط مطمئن می‌شویم یک ادمین مطابق env وجود دارد.
     */
    function dy_sync_admin_from_env(PDO $pdo, string $adminUser, string $adminPass, array &$messages = []): void {
        if (!dy_table_exists($pdo, 'users')) return;

        $adminUser = trim($adminUser);
        if ($adminUser === '') {
            $messages[] = ['err', '⚠ ADMIN_USER در فایل env خالی است؛ ادمین env ساخته نشد.'];
            return;
        }
        if ($adminPass === '') {
            $messages[] = ['err', '⚠ ADMIN_PASS در فایل env خالی است؛ برای امنیت حتماً مقدار بده.'];
        }

        $hash = password_hash($adminPass, PASSWORD_BCRYPT);

        try {
            // اگر کاربری با همین نام/موبایل env وجود دارد، همان را ادمین و رمز را مطابق env می‌کنیم.
            $st = $pdo->prepare("SELECT id FROM users WHERE mobile=? LIMIT 1");
            $st->execute([$adminUser]);
            $id = (int)($st->fetchColumn() ?: 0);

            if ($id > 0) {
                $up = $pdo->prepare("UPDATE users SET password=?, role='admin', status='active' WHERE id=?");
                $up->execute([$hash, $id]);
                $messages[] = ['ok', '✓ ادمین مطابق فایل env به‌روزرسانی شد: ' . htmlspecialchars($adminUser, ENT_QUOTES, 'UTF-8')];
                return;
            }

            // اگر ادمین پیش‌فرض/قدیمی وجود دارد، همان را به ادمین env تبدیل می‌کنیم تا duplicate نسازیم.
            $st = $pdo->query("SELECT id FROM users WHERE role='admin' ORDER BY id ASC LIMIT 1");
            $id = (int)($st->fetchColumn() ?: 0);

            if ($id > 0) {
                $up = $pdo->prepare("UPDATE users SET mobile=?, password=?, role='admin', status='active' WHERE id=?");
                $up->execute([$adminUser, $hash, $id]);
                $messages[] = ['ok', '✓ ادمین موجود با فایل env هماهنگ شد: ' . htmlspecialchars($adminUser, ENT_QUOTES, 'UTF-8')];
                return;
            }

            // در غیر این صورت یک ادمین جدید از env می‌سازیم.
            $ins = $pdo->prepare("INSERT INTO users (first_name,last_name,mobile,password,grade,major,school,role,status) VALUES ('مدیر','سیستم',?,?,12,'math','مدیریت','admin','active')");
            $ins->execute([$adminUser, $hash]);
            $messages[] = ['ok', '✓ ادمین جدید از فایل env ساخته شد: ' . htmlspecialchars($adminUser, ENT_QUOTES, 'UTF-8')];
        } catch (Throwable $e) {
            $messages[] = ['err', '⚠ خطا در هماهنگ‌سازی ادمین با env: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')];
        }
    }
}

if (!function_exists('dy_safe_update_schema')) {
    /**
     * نصب/آپدیت امن همه جدول‌ها و ستون‌های شناخته‌شده پروژه.
     */
    function dy_safe_update_schema(PDO $pdo, string $adminHash): array {
        $messages = [];

        dy_run_base_install_sql_safely($pdo, $adminHash, $messages);

        // users
        dy_add_column_if_missing($pdo, 'users', 'major', "`major` VARCHAR(30) NOT NULL DEFAULT 'math' AFTER `grade`", $messages);
        dy_add_column_if_missing($pdo, 'users', 'status', "`status` ENUM('active','banned') NOT NULL DEFAULT 'active' AFTER `role`", $messages);
        dy_add_column_if_missing($pdo, 'users', 'ban_reason', "`ban_reason` VARCHAR(255) DEFAULT NULL AFTER `status`", $messages);
        dy_add_column_if_missing($pdo, 'users', 'subscription_type', "`subscription_type` VARCHAR(50) NOT NULL DEFAULT 'none'", $messages);
        dy_add_column_if_missing($pdo, 'users', 'subscription_start', "`subscription_start` DATETIME DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'users', 'subscription_end', "`subscription_end` DATETIME DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'users', 'messages_used_total', "`messages_used_total` INT DEFAULT 0", $messages);
        dy_add_column_if_missing($pdo, 'users', 'messages_used_today', "`messages_used_today` INT DEFAULT 0", $messages);
        dy_add_column_if_missing($pdo, 'users', 'free_used_today', "`free_used_today` TINYINT DEFAULT 0", $messages);
        dy_add_column_if_missing($pdo, 'users', 'last_reset_date', "`last_reset_date` DATE DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'users', 'created_at', "`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP", $messages);
        dy_add_index_if_missing($pdo, 'users', 'idx_users_grade_major', 'INDEX `idx_users_grade_major` (`grade`, `major`)', $messages);

        // books
        dy_add_column_if_missing($pdo, 'books', 'subject', "`subject` VARCHAR(80) NOT NULL DEFAULT '' AFTER `grade`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'major', "`major` VARCHAR(30) NOT NULL DEFAULT 'all' AFTER `subject`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'majors', "`majors` VARCHAR(200) NOT NULL DEFAULT 'all' AFTER `major`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'file_name', "`file_name` VARCHAR(255) NOT NULL DEFAULT '' AFTER `majors`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'file_names', "`file_names` TEXT DEFAULT NULL AFTER `file_name`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'cached_text', "`cached_text` LONGTEXT DEFAULT NULL AFTER `file_names`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'chunks_count', "`chunks_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0 AFTER `cached_text`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'extract_mode', "`extract_mode` VARCHAR(12) NOT NULL DEFAULT 'summary' AFTER `chunks_count`", $messages);
        dy_add_column_if_missing($pdo, 'books', 'created_at', "`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP", $messages);
        dy_add_index_if_missing($pdo, 'books', 'idx_books_grade_major', 'INDEX `idx_books_grade_major` (`grade`, `major`)', $messages);

        // book_chunks
        dy_add_column_if_missing($pdo, 'book_chunks', 'page_start', "`page_start` SMALLINT UNSIGNED DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'book_chunks', 'page_end', "`page_end` SMALLINT UNSIGNED DEFAULT NULL", $messages);
        dy_add_index_if_missing($pdo, 'book_chunks', 'idx_chunk_book', 'INDEX `idx_chunk_book` (`book_id`)', $messages);
        dy_add_index_if_missing($pdo, 'book_chunks', 'idx_chunk_keywords', 'INDEX `idx_chunk_keywords` (`book_id`, `chunk_index`)', $messages);
        try { $pdo->exec("ALTER TABLE `book_chunks` ADD FULLTEXT INDEX `ft_chunk_content` (`content`, `keywords`)"); $messages[] = ['ok', '✓ FULLTEXT کتاب‌ها آماده شد']; } catch (Throwable $e) {}

        // chats/chat_history
        dy_add_column_if_missing($pdo, 'chat_history', 'chat_id', "`chat_id` INT DEFAULT NULL AFTER `user_id`", $messages);
        dy_add_column_if_missing($pdo, 'chat_history', 'book_id', "`book_id` INT DEFAULT NULL AFTER `chat_id`", $messages);
        dy_add_column_if_missing($pdo, 'chat_history', 'attachment', "`attachment` VARCHAR(255) DEFAULT NULL", $messages);
        dy_add_index_if_missing($pdo, 'chat_history', 'chat_id', 'INDEX `chat_id` (`chat_id`)', $messages);

        // transactions/card receipts
        dy_add_column_if_missing($pdo, 'transactions', 'activate_at', "`activate_at` DATETIME DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'transactions', 'payment_method', "`payment_method` ENUM('card','online','manual') DEFAULT 'manual'", $messages);
        dy_add_column_if_missing($pdo, 'transactions', 'note', "`note` TEXT DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'card_receipts', 'activate_at', "`activate_at` DATETIME DEFAULT NULL COMMENT 'زمان دلخواه فعال‌سازی'", $messages);
        dy_add_column_if_missing($pdo, 'card_receipts', 'reviewed_at', "`reviewed_at` DATETIME DEFAULT NULL", $messages);
        dy_add_column_if_missing($pdo, 'card_receipts', 'reviewed_by', "`reviewed_by` INT DEFAULT NULL", $messages);
        try { $pdo->exec("ALTER TABLE `card_receipts` MODIFY COLUMN `status` ENUM('pending','approved_pending','approved','rejected') DEFAULT 'pending'"); } catch (Throwable $e) {}

        // جداول جانبی‌ای که ممکن است در نسخه‌های قدیمی نباشند.
        dy_exec_safe($pdo, "CREATE TABLE IF NOT EXISTS `user_discounts` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` INT NOT NULL,
            `discount_percent` TINYINT NOT NULL DEFAULT 0,
            `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `uniq_user_discount` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci", $messages);

        // ادمین باید دقیقاً از فایل env پیروی کند.
        dy_sync_admin_from_env($pdo, defined('ADMIN_USER') ? ADMIN_USER : 'webmania', defined('ADMIN_PASS') ? ADMIN_PASS : '', $messages);

        $messages[] = ['ok', '✅ آپدیت امن ساختار دیتابیس کامل شد؛ اطلاعات قبلی حذف یا ریست نشد.'];
        return $messages;
    }
}
