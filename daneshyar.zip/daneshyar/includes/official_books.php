<?php
/**
 * ============================================================
 *  دانش‌یار - تزریق کتاب‌های رسمی آماده به دیتابیس
 * ------------------------------------------------------------
 *  این فایل کتاب‌هایی را که متن خط‌به‌خط‌شان داخل sql/seeds آمده
 *  به صورت idempotent وارد جدول books و book_chunks می‌کند.
 * ============================================================
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/book_chunker.php';


if (!function_exists('dy_seed_db')) {
    /**
     * هنگام اجرای install.php از همان اتصال PDO نصب استفاده می‌کنیم تا روی هاست
     * به خاطر تفاوت اتصال/کاربر/دیتابیس، seed کتاب‌ها از دیتابیس جدا نیفتد.
     */
    function dy_seed_db(): PDO {
        if (!empty($GLOBALS['dy_seed_pdo']) && $GLOBALS['dy_seed_pdo'] instanceof PDO) {
            return $GLOBALS['dy_seed_pdo'];
        }
        return db();
    }
}

if (!function_exists('seed_official_books')) {
    function seed_official_books(?PDO $pdo = null): array {
        if ($pdo instanceof PDO) { $GLOBALS['dy_seed_pdo'] = $pdo; }
        $results = [];
        $results[] = seed_amar_ehtemal_11();
        $results[] = seed_zamin_shenasi_11_math();
        $results[] = seed_riazi_amoozesh_ebtedayi_university();
        return $results;
    }
}

if (!function_exists('seed_amar_ehtemal_11')) {
    /**
     * افزودن/به‌روزرسانی کتاب «آمار و احتمال یازدهم» با متن خط‌به‌خط.
     * خروجی: ['ok'=>bool, 'title'=>string, 'book_id'=>int|null, 'chunks'=>int, 'message'=>string]
     */
    function seed_amar_ehtemal_11(): array {
        $title   = 'آمار و احتمال یازدهم ریاضی فیزیک (۱۴۰۴-۱۴۰۵)';
        $subject = 'آمار و احتمال';
        $grade   = 11;
        $major   = 'math';
        $file    = 'amar-ehtemal-11-1404-1405.pdf';

        $seedPath = dirname(__DIR__) . '/sql/seeds/amar_ehtemal_11_line_by_line.txt';
        $pdfPath  = dirname(__DIR__) . '/books/' . $file;

        if (!is_file($seedPath)) {
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'فایل seed متن خط‌به‌خط پیدا نشد: ' . $seedPath];
        }
        if (!is_file($pdfPath)) {
            // PDF برای RAG ضروری نیست، ولی برای دانلود/مدیریت کتاب بهتر است وجود داشته باشد.
            // بنابراین فقط پیام هشدار می‌دهیم و تزریق متن را ادامه می‌دهیم.
        }

        $text = trim((string)@file_get_contents($seedPath));
        if (mb_strlen($text, 'UTF-8') < 1000) {
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'محتوای seed خیلی کم یا نامعتبر است.'];
        }

        ensure_seed_book_schema();

        try {
            $pdo = dy_seed_db();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT id FROM books
                WHERE grade=?
                  AND (title LIKE '%آمار%' OR subject LIKE '%آمار%')
                  AND (title LIKE '%احتمال%' OR subject LIKE '%احتمال%')
                  AND (major IN (?, 'all', '') OR COALESCE(majors, major, '') LIKE ? OR COALESCE(majors, major, '') LIKE '%all%')
                ORDER BY id ASC LIMIT 1");
            $stmt->execute([$grade, $major, '%' . $major . '%']);
            $bookId = (int)($stmt->fetchColumn() ?: 0);

            if ($bookId > 0) {
                $up = $pdo->prepare("UPDATE books
                    SET title=?, grade=?, subject=?, major=?, majors=?, file_name=?, file_names=?, cached_text=?, extract_mode='detailed'
                    WHERE id=?");
                $up->execute([$title, $grade, $subject, $major, $major, $file, $file, $text, $bookId]);
            } else {
                $ins = $pdo->prepare("INSERT INTO books (title, grade, subject, major, majors, file_name, file_names, cached_text, extract_mode, chunks_count)
                    VALUES (?,?,?,?,?,?,?,?, 'detailed', 0)");
                $ins->execute([$title, $grade, $subject, $major, $major, $file, $file, $text]);
                $bookId = (int)$pdo->lastInsertId();
            }

            $pdo->prepare("DELETE FROM book_chunks WHERE book_id=?")->execute([$bookId]);

            $chunks = amar_ehtemal_11_page_chunks($text);
            $insert = $pdo->prepare("INSERT INTO book_chunks (book_id, chunk_index, title, content, keywords, page_start, page_end)
                VALUES (?,?,?,?,?,?,?)");

            foreach ($chunks as $i => $chunk) {
                $insert->execute([
                    $bookId,
                    $i,
                    $chunk['title'],
                    $chunk['content'],
                    $chunk['keywords'],
                    $chunk['page_start'],
                    $chunk['page_end'],
                ]);
            }

            $pdo->prepare("UPDATE books SET chunks_count=? WHERE id=?")->execute([count($chunks), $bookId]);
            $pdo->commit();

            return [
                'ok' => true,
                'title' => $title,
                'book_id' => $bookId,
                'chunks' => count($chunks),
                'message' => 'کتاب آمار و احتمال یازدهم با متن خط‌به‌خط به‌روزرسانی شد.'
            ];
        } catch (Throwable $e) {
            try { if (dy_seed_db()->inTransaction()) dy_seed_db()->rollBack(); } catch (Throwable $ignored) {}
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'خطا در seed کتاب: ' . $e->getMessage()];
        }
    }
}


if (!function_exists('seed_zamin_shenasi_11_math')) {
    /**
     * افزودن/به‌روزرسانی کتاب «زمین‌شناسی یازدهم» برای پایه یازدهم رشته ریاضی.
     * خروجی: ['ok'=>bool, 'title'=>string, 'book_id'=>int|null, 'chunks'=>int, 'message'=>string]
     */
    function seed_zamin_shenasi_11_math(): array {
        $title   = 'زمین‌شناسی یازدهم ریاضی (۱۴۰۴-۱۴۰۵)';
        $subject = 'زمین شناسی';
        $grade   = 11;
        $major   = 'math';
        $file    = 'zamin-shenasi-11-1404-1405.pdf';

        $seedPath = dirname(__DIR__) . '/sql/seeds/zamin_shenasi_11_line_by_line.txt';
        $pdfPath  = dirname(__DIR__) . '/books/' . $file;

        if (!is_file($seedPath)) {
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'فایل seed متن خط‌به‌خط زمین‌شناسی پیدا نشد: ' . $seedPath];
        }
        if (!is_file($pdfPath)) {
            // PDF برای RAG ضروری نیست، ولی برای مدیریت/دانلود بهتر است کنار seed بماند.
        }

        $text = trim((string)@file_get_contents($seedPath));
        if (mb_strlen($text, 'UTF-8') < 1000) {
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'محتوای seed زمین‌شناسی خیلی کم یا نامعتبر است.'];
        }

        ensure_seed_book_schema();

        try {
            $pdo = dy_seed_db();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT id FROM books
                WHERE grade=?
                  AND (title LIKE '%زمین%' OR subject LIKE '%زمین%')
                  AND (title LIKE '%شناسی%' OR subject LIKE '%شناسی%')
                  AND (major IN (?, 'all', '') OR COALESCE(majors, major, '') LIKE ? OR COALESCE(majors, major, '') LIKE '%all%')
                ORDER BY id ASC LIMIT 1");
            $stmt->execute([$grade, $major, '%' . $major . '%']);
            $bookId = (int)($stmt->fetchColumn() ?: 0);

            if ($bookId > 0) {
                $up = $pdo->prepare("UPDATE books
                    SET title=?, grade=?, subject=?, major=?, majors=?, file_name=?, file_names=?, cached_text=?, extract_mode='detailed'
                    WHERE id=?");
                $up->execute([$title, $grade, $subject, $major, $major, $file, $file, $text, $bookId]);
            } else {
                $ins = $pdo->prepare("INSERT INTO books (title, grade, subject, major, majors, file_name, file_names, cached_text, extract_mode, chunks_count)
                    VALUES (?,?,?,?,?,?,?,?, 'detailed', 0)");
                $ins->execute([$title, $grade, $subject, $major, $major, $file, $file, $text]);
                $bookId = (int)$pdo->lastInsertId();
            }

            $pdo->prepare("DELETE FROM book_chunks WHERE book_id=?")->execute([$bookId]);

            $chunks = zamin_shenasi_11_page_chunks($text);
            $insert = $pdo->prepare("INSERT INTO book_chunks (book_id, chunk_index, title, content, keywords, page_start, page_end)
                VALUES (?,?,?,?,?,?,?)");

            foreach ($chunks as $i => $chunk) {
                $insert->execute([
                    $bookId,
                    $i,
                    $chunk['title'],
                    $chunk['content'],
                    $chunk['keywords'],
                    $chunk['page_start'],
                    $chunk['page_end'],
                ]);
            }

            $pdo->prepare("UPDATE books SET chunks_count=? WHERE id=?")->execute([count($chunks), $bookId]);
            $pdo->commit();

            return [
                'ok' => true,
                'title' => $title,
                'book_id' => $bookId,
                'chunks' => count($chunks),
                'message' => 'کتاب زمین‌شناسی یازدهم رشته ریاضی با متن خط‌به‌خط به‌روزرسانی شد.'
            ];
        } catch (Throwable $e) {
            try { if (dy_seed_db()->inTransaction()) dy_seed_db()->rollBack(); } catch (Throwable $ignored) {}
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'خطا در seed کتاب زمین‌شناسی: ' . $e->getMessage()];
        }
    }
}


if (!function_exists('seed_riazi_amoozesh_ebtedayi_university')) {
    /**
     * افزودن/به‌روزرسانی منبع دانشگاهی «ریاضی آموزش و پرورش ابتدایی».
     * نکته: در سامانه برای دسترسی، پایه ۱۲ و رشته other ثبت می‌شود؛ ماهیت واقعی دانشگاهی است.
     */
    function seed_riazi_amoozesh_ebtedayi_university(): array {
        $title   = 'ریاضی آموزش و پرورش ابتدایی (دانشگاهی)';
        $subject = 'ریاضی';
        $grade   = 12;
        $major   = 'other';
        $file    = 'riazi-amoozesh-parvaresh-ebtedayi-university.txt';

        $seedPath = dirname(__DIR__) . '/sql/seeds/riazi_amoozesh_parvaresh_ebtedayi_university.txt';
        if (!is_file($seedPath)) {
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'فایل seed ریاضی آموزش و پرورش ابتدایی پیدا نشد: ' . $seedPath];
        }

        $text = trim((string)@file_get_contents($seedPath));
        if (mb_strlen($text, 'UTF-8') < 1000) {
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'محتوای seed ریاضی آموزش و پرورش ابتدایی خیلی کم یا نامعتبر است.'];
        }

        ensure_seed_book_schema();

        try {
            $pdo = dy_seed_db();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT id FROM books
                WHERE grade=?
                  AND (title LIKE '%ریاضی%' OR subject LIKE '%ریاضی%')
                  AND (title LIKE '%ابتدایی%' OR title LIKE '%آموزش و پرورش%' OR title LIKE '%اموزش و پرورش%')
                  AND (major IN (?, 'all', '') OR COALESCE(majors, major, '') LIKE ? OR COALESCE(majors, major, '') LIKE '%all%')
                ORDER BY id ASC LIMIT 1");
            $stmt->execute([$grade, $major, '%' . $major . '%']);
            $bookId = (int)($stmt->fetchColumn() ?: 0);

            if ($bookId > 0) {
                $up = $pdo->prepare("UPDATE books
                    SET title=?, grade=?, subject=?, major=?, majors=?, file_name=?, file_names=?, cached_text=?, extract_mode='detailed'
                    WHERE id=?");
                $up->execute([$title, $grade, $subject, $major, $major, $file, $file, $text, $bookId]);
            } else {
                $ins = $pdo->prepare("INSERT INTO books (title, grade, subject, major, majors, file_name, file_names, cached_text, extract_mode, chunks_count)
                    VALUES (?,?,?,?,?,?,?,?, 'detailed', 0)");
                $ins->execute([$title, $grade, $subject, $major, $major, $file, $file, $text]);
                $bookId = (int)$pdo->lastInsertId();
            }

            $pdo->prepare("DELETE FROM book_chunks WHERE book_id=?")->execute([$bookId]);

            $chunks = riazi_ebtedayi_university_chunks($text);
            $insert = $pdo->prepare("INSERT INTO book_chunks (book_id, chunk_index, title, content, keywords, page_start, page_end)
                VALUES (?,?,?,?,?,?,?)");

            foreach ($chunks as $i => $chunk) {
                $insert->execute([
                    $bookId,
                    $i,
                    $chunk['title'],
                    $chunk['content'],
                    $chunk['keywords'],
                    $chunk['page_start'],
                    $chunk['page_end'],
                ]);
            }

            $pdo->prepare("UPDATE books SET chunks_count=? WHERE id=?")->execute([count($chunks), $bookId]);
            $pdo->commit();

            return [
                'ok' => true,
                'title' => $title,
                'book_id' => $bookId,
                'chunks' => count($chunks),
                'message' => 'کتاب دانشگاهی ریاضی آموزش و پرورش ابتدایی برای پایه ۱۲ رشته سایر رشته‌ها به‌روزرسانی شد.'
            ];
        } catch (Throwable $e) {
            try { if (dy_seed_db()->inTransaction()) dy_seed_db()->rollBack(); } catch (Throwable $ignored) {}
            return ['ok'=>false, 'title'=>$title, 'book_id'=>null, 'chunks'=>0, 'message'=>'خطا در seed ریاضی آموزش و پرورش ابتدایی: ' . $e->getMessage()];
        }
    }
}

if (!function_exists('riazi_ebtedayi_university_chunks')) {
    function riazi_ebtedayi_university_chunks(string $text): array {
        $parts = preg_split('/^##\s*صفحه\s+(\d+)\s*$/mu', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $chunks = [];

        for ($i = 1; $i < count($parts); $i += 2) {
            $page = (int)$parts[$i];
            $content = trim((string)($parts[$i + 1] ?? ''));
            if ($page <= 0 || $content === '') continue;

            $content = "## صفحه {$page}\n" . $content;
            $titleLine = amar_first_meaningful_line($content);
            $title = 'بخش ' . $page . ($titleLine ? ' — ' . mb_substr($titleLine, 0, 90, 'UTF-8') : '');
            $keywords = function_exists('extract_kw') ? extract_kw($content) : '';

            $chunks[] = [
                'title' => $title,
                'content' => $content,
                'keywords' => $keywords . ' ریاضی دانشگاهی آموزش و پرورش ابتدایی معلم ابتدایی عدد کسر اعشار نسبت درصد جبر معادله نامعادله تابع هندسه مساحت حجم آمار احتمال حل مسئله آموزش ریاضی',
                'page_start' => $page,
                'page_end' => $page,
            ];
        }

        if (empty($chunks)) return chunk_book_text($text);
        return $chunks;
    }
}


if (!function_exists('ensure_seed_book_schema')) {
    /**
     * آماده‌سازی حداقلی schema با همان PDO فعال seed.
     */
    function ensure_seed_book_schema(): void {
        $pdo = dy_seed_db();
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS `books` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `title` VARCHAR(150) NOT NULL,
              `grade` TINYINT NOT NULL,
              `subject` VARCHAR(80) NOT NULL,
              `major` VARCHAR(30) NOT NULL DEFAULT 'all',
              `majors` VARCHAR(200) NOT NULL DEFAULT 'all',
              `file_name` VARCHAR(255) NOT NULL DEFAULT '',
              `file_names` TEXT DEFAULT NULL,
              `cached_text` LONGTEXT DEFAULT NULL,
              `chunks_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
              `extract_mode` VARCHAR(12) NOT NULL DEFAULT 'summary',
              `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
              INDEX `idx_books_grade_major` (`grade`, `major`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (Throwable $e) {}

        ensure_books_extra_columns_for_seed();

        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS `book_chunks` (
              `id` INT AUTO_INCREMENT PRIMARY KEY,
              `book_id` INT NOT NULL,
              `chunk_index` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
              `title` VARCHAR(200) NOT NULL DEFAULT '',
              `content` MEDIUMTEXT NOT NULL,
              `keywords` TEXT DEFAULT NULL,
              `page_start` SMALLINT UNSIGNED DEFAULT NULL,
              `page_end` SMALLINT UNSIGNED DEFAULT NULL,
              `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
              INDEX `idx_chunk_book` (`book_id`),
              INDEX `idx_chunk_keywords` (`book_id`, `chunk_index`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (Throwable $e) {}

        try { $pdo->exec("ALTER TABLE `book_chunks` ADD COLUMN `page_start` SMALLINT UNSIGNED DEFAULT NULL"); } catch (Throwable $e) {}
        try { $pdo->exec("ALTER TABLE `book_chunks` ADD COLUMN `page_end` SMALLINT UNSIGNED DEFAULT NULL"); } catch (Throwable $e) {}
        try { $pdo->exec("ALTER TABLE `book_chunks` ADD FULLTEXT INDEX `ft_chunk_content` (`content`, `keywords`)"); } catch (Throwable $e) {}
    }
}

if (!function_exists('ensure_books_extra_columns_for_seed')) {
    function ensure_books_extra_columns_for_seed(): void {
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN grade TINYINT NOT NULL DEFAULT 11 AFTER title"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN subject VARCHAR(80) NOT NULL DEFAULT '' AFTER grade"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN major VARCHAR(30) NOT NULL DEFAULT 'all' AFTER subject"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN majors VARCHAR(200) NOT NULL DEFAULT 'all' AFTER major"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN file_name VARCHAR(255) NOT NULL DEFAULT '' AFTER majors"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN file_names TEXT DEFAULT NULL AFTER file_name"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN cached_text LONGTEXT DEFAULT NULL AFTER file_names"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN chunks_count SMALLINT UNSIGNED NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN extract_mode VARCHAR(12) NOT NULL DEFAULT 'summary'"); } catch (Throwable $e) {}
        try { dy_seed_db()->exec("ALTER TABLE books ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP"); } catch (Throwable $e) {}
    }
}

if (!function_exists('amar_ehtemal_11_page_chunks')) {
    /**
     * تبدیل فایل خط‌به‌خط به chunkهای صفحه‌محور.
     * صفحه‌محور بودن باعث می‌شود اگر دانش‌آموز بگوید «صفحه ۷۲» یا عکس آزمون از همان بخش باشد،
     * RAG دقیق‌تر متن همان صفحه را پیدا کند.
     */
    function amar_ehtemal_11_page_chunks(string $text): array {
        $parts = preg_split('/^##\s*صفحه\s+(\d+)\s*$/mu', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $chunks = [];

        for ($i = 1; $i < count($parts); $i += 2) {
            $page = (int)$parts[$i];
            $content = trim((string)($parts[$i + 1] ?? ''));
            if ($page <= 0 || $content === '') continue;

            $content = "## صفحه {$page}\n" . $content;
            $titleLine = amar_first_meaningful_line($content);
            $title = 'صفحه ' . $page . ($titleLine ? ' — ' . mb_substr($titleLine, 0, 90, 'UTF-8') : '');
            $keywords = function_exists('extract_kw') ? extract_kw($content) : '';

            $chunks[] = [
                'title' => $title,
                'content' => $content,
                'keywords' => $keywords . ' آمار احتمال یازدهم ریاضی منطق مجموعه داده میانگین میانه مد واریانس انحراف معیار احتمال شرطی مستقل وابسته نمونه جامعه برآورد',
                'page_start' => $page,
                'page_end' => $page,
            ];
        }

        // اگر به هر دلیل parsing شکست خورد، از chunker عمومی استفاده می‌کنیم.
        if (empty($chunks)) {
            return chunk_book_text($text);
        }
        return $chunks;
    }
}


if (!function_exists('zamin_shenasi_11_page_chunks')) {
    /**
     * تبدیل seed خط‌به‌خط زمین‌شناسی به chunkهای صفحه‌محور.
     */
    function zamin_shenasi_11_page_chunks(string $text): array {
        $parts = preg_split('/^##\s*صفحه\s+(\d+)\s*$/mu', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $chunks = [];

        for ($i = 1; $i < count($parts); $i += 2) {
            $page = (int)$parts[$i];
            $content = trim((string)($parts[$i + 1] ?? ''));
            if ($page <= 0 || $content === '') continue;

            $content = "## صفحه {$page}\n" . $content;
            $titleLine = amar_first_meaningful_line($content);
            $title = 'صفحه ' . $page . ($titleLine ? ' — ' . mb_substr($titleLine, 0, 90, 'UTF-8') : '');
            $keywords = function_exists('extract_kw') ? extract_kw($content) : '';

            $chunks[] = [
                'title' => $title,
                'content' => $content,
                'keywords' => $keywords . ' زمین شناسی یازدهم ریاضی تجربی کیهان زمین معدن منابع معدنی انرژی آب خاک پویا پویایی زلزله آتشفشان سلامت سازه مهندسی زمین شناسی ایران کانی سنگ گسل فرسایش رسوب نفت گاز آبخوان',
                'page_start' => $page,
                'page_end' => $page,
            ];
        }

        if (empty($chunks)) {
            return chunk_book_text($text);
        }
        return $chunks;
    }
}

if (!function_exists('amar_first_meaningful_line')) {
    function amar_first_meaningful_line(string $content): string {
        $lines = preg_split('/\n/u', $content);
        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '' || preg_match('/^##\s*صفحه/u', $line)) continue;
            $line = preg_replace('/^\[\d{3}\]\s*/u', '', $line);
            if (mb_strlen($line, 'UTF-8') >= 4) return $line;
        }
        return '';
    }
}
