<?php
/**
 * ساخت SQL ادمین با hash واقعی
 * این فایل رو اجرا کن → SQL تولید میشه → کپی کن تو MySQL
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/env.php';

$adminUser = ADMIN_USER;
$adminPass = ADMIN_PASS;
$adminHash = password_hash($adminPass, PASSWORD_BCRYPT);

echo "=====================================\n";
echo "  SQL ادمین (آماده اجرا در MySQL)\n";
echo "=====================================\n\n";

echo "USE daneshyar;\n\n";

echo "-- حذف ادمین قبلی (اختیاری)\n";
echo "DELETE FROM `users` WHERE `role` = 'admin';\n\n";

echo "-- ثبت ادمین جدید\n";
echo "INSERT INTO `users` (`first_name`, `last_name`, `mobile`, `password`, `grade`, `major`, `school`, `role`, `status`)\n";
echo "VALUES ('مدیر', 'سیستم', '{$adminUser}', '{$adminHash}', 12, 'math', 'مدیریت', 'admin', 'active');\n\n";

echo "-- تأیید\n";
echo "SELECT '✅ ادمین ساخته شد' AS result;\n";

echo "\n=====================================\n";
echo "  اطلاعات ادمین:\n";
echo "=====================================\n";
echo "یوزرنیم: {$adminUser}\n";
echo "رمز: {$adminPass}\n";
echo "Hash: {$adminHash}\n";
