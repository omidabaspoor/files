<?php
/**
 * نصب دانش‌یار
 * - ساخت دیتابیس و جداول
 * - ثبت ادمین (از env)
 * - نصب کتاب فیزیک یازدهم (ID=40)
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/env.php';

$messages = [];
$success = false;

try {
    // اتصال به MySQL
    $pdo = new PDO("mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
    ]);
    $messages[] = ['ok', '✓ اتصال به MySQL'];

    // ساخت دیتابیس
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `" . DB_NAME . "`");
    $messages[] = ['ok', '✓ دیتابیس <b>' . DB_NAME . '</b>'];

    // خواندن و اجرای install.sql
    $sql = file_get_contents(__DIR__ . '/sql/install.sql');
    
    // جایگذاری ادمین
    $adminHash = password_hash(ADMIN_PASS, PASSWORD_BCRYPT);
    $sql = str_replace('__ADMIN_HASH__', $adminHash, $sql);
    $sql = str_replace('__ADMIN_USER__', ADMIN_USER, $sql);
    
    // حذف CREATE DATABASE و USE (چون خودمون انجام دادیم)
    $sql = preg_replace('/CREATE DATABASE.*?;/is', '', $sql, 1);
    $sql = preg_replace('/USE\s+`?\w+`?\s*;/i', '', $sql);
    
    // حذف کامنت‌ها
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    
    // تقسیم به statements
    $statements = array_filter(
        array_map('trim', preg_split('/;\s*[\r\n]+/', $sql)),
        fn($s) => !empty($s)
    );
    
    foreach ($statements as $stmt) {
        if (empty($stmt)) continue;
        try {
            $result = $pdo->query($stmt);
            if ($result !== false && method_exists($result, 'closeCursor')) {
                $result->closeCursor();
            }
        } catch (Throwable $e) {
            if (stripos($e->getMessage(), 'Duplicate') !== false || 
                stripos($e->getMessage(), 'already exists') !== false) {
                continue;
            }
            // خطاهای دیگه رو نادیده بگیر (برای compatibility)
        }
    }
    $messages[] = ['ok', '✓ جداول ساخته شدند'];

    // ساخت پوشه‌ها
    foreach (['/books', '/uploads', '/uploads/receipts'] as $d) {
        if (!is_dir(__DIR__ . $d)) { @mkdir(__DIR__ . $d, 0755, true); }
    }
    $messages[] = ['ok', '✓ پوشه‌ها آماده شدند'];

    // ادمین
    $messages[] = ['ok', '✓ ادمین: <code>' . ADMIN_USER . '</code> / <code>' . ADMIN_PASS . '</code>'];

    // ═══════════════════════════════════════════════════════════════
    // نصب کتاب فیزیک یازدهم (ID=40)
    // ═══════════════════════════════════════════════════════════════
    
    // بررسی وجود
    $checkStmt = $pdo->prepare("SELECT id FROM books WHERE id = 40");
    $checkStmt->execute();
    $existing = $checkStmt->fetch();
    $checkStmt->closeCursor();
    
    if (!$existing) {
        // خواندن فایل SQL
        $physicsSql = file_get_contents(__DIR__ . '/install_physics11_manual.sql');
        
        // حذف کامنت‌ها
        $physicsSql = preg_replace('/^\s*--.*$/m', '', $physicsSql);
        
        // حذف USE (چون الان وصلیم)
        $physicsSql = preg_replace('/USE\s+\w+\s*;/i', '', $physicsSql);
        
        // تقسیم به statements
        $physicsStmts = array_filter(
            array_map('trim', preg_split('/;\s*[\r\n]+/', $physicsSql)),
            fn($s) => !empty($s)
        );
        
        foreach ($physicsStmts as $stmt) {
            if (empty($stmt)) continue;
            try {
                $result = $pdo->query($stmt);
                if ($result !== false && method_exists($result, 'closeCursor')) {
                    $result->closeCursor();
                }
            } catch (Throwable $e) {
                if (stripos($e->getMessage(), 'Duplicate') !== false) continue;
                // خطای دیگه رو نشون بده
                throw $e;
            }
        }
        
        $messages[] = ['ok', '✓ کتاب فیزیک یازدهم (ID=40) نصب شد'];
    } else {
        $messages[] = ['ok', '✓ کتاب فیزیک یازدهم (ID=40) موجود است'];
    }

    // ═══════════════════════════════════════════════════════════════
    // نصب کتاب ریاضی یازدهم انسانی (ID=41)
    // ═══════════════════════════════════════════════════════════════
    
    // بررسی وجود
    $checkStmt = $pdo->prepare("SELECT id FROM books WHERE id = 41");
    $checkStmt->execute();
    $existing = $checkStmt->fetch();
    $checkStmt->closeCursor();
    
    if (!$existing) {
        // خواندن فایل SQL
        $mathSql = file_get_contents(__DIR__ . '/install_math11_humanities.sql');
        
        // حذف کامنت‌ها
        $mathSql = preg_replace('/^\s*--.*$/m', '', $mathSql);
        
        // حذف USE (چون الان وصلیم)
        $mathSql = preg_replace('/USE\s+\w+\s*;/i', '', $mathSql);
        
        // تقسیم به statements
        $mathStmts = array_filter(
            array_map('trim', preg_split('/;\s*[\r\n]+/', $mathSql)),
            fn($s) => !empty($s)
        );
        
        foreach ($mathStmts as $stmt) {
            if (empty($stmt)) continue;
            try {
                $result = $pdo->query($stmt);
                if ($result !== false && method_exists($result, 'closeCursor')) {
                    $result->closeCursor();
                }
            } catch (Throwable $e) {
                if (stripos($e->getMessage(), 'Duplicate') !== false) continue;
                // خطای دیگه رو نشون بده
                throw $e;
            }
        }
        
        $messages[] = ['ok', '✓ کتاب ریاضی یازدهم انسانی (ID=41) نصب شد'];
    } else {
        $messages[] = ['ok', '✓ کتاب ریاضی یازدهم انسانی (ID=41) موجود است'];
    }
    
    $success = true;
    
} catch (Throwable $e) {
    $messages[] = ['err', '❌ خطا: ' . $e->getMessage()];
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>نصب دانش‌یار</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<style>
body { font-family: Vazirmatn, Tahoma; background: #0a0a10; color: #fff; padding: 40px 20px; }
.auth-wrap { max-width: 600px; margin: 0 auto; }
.auth-card { background: rgba(255,255,255,0.05); border: 1px solid rgba(235,124,42,0.3); border-radius: 20px; padding: 40px; }
h1 { text-align: center; color: #eb7c2a; margin-bottom: 10px; }
.sub { text-align: center; color: #888; margin-bottom: 30px; }
.alert { padding: 15px; margin: 10px 0; border-radius: 10px; border: 1px solid; }
.alert-success { background: rgba(34,197,94,0.1); border-color: rgba(34,197,94,0.3); color: #22c55e; }
.alert-error { background: rgba(239,68,68,0.1); border-color: rgba(239,68,68,0.3); color: #ef4444; }
.alert-info { background: rgba(59,130,246,0.1); border-color: rgba(59,130,246,0.3); color: #3b82f6; margin-top: 20px; }
code { background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 4px; font-family: monospace; }
.btn { display: block; text-align: center; padding: 15px; margin-top: 20px; background: #eb7c2a; color: #fff; text-decoration: none; border-radius: 10px; font-weight: 700; }
.btn:hover { background: #d96a1a; }
</style>
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <h1>⚙️ نصب دانش‌یار</h1>
    <p class="sub">گزارش نصب:</p>
    
    <?php foreach ($messages as [$type, $msg]): ?>
      <div class="alert alert-<?= $type === 'ok' ? 'success' : 'error' ?>"><?= $msg ?></div>
    <?php endforeach; ?>

    <?php if ($success): ?>
      <div class="alert alert-info">
        <b>پنل ادمین:</b> <code>/admin</code><br><br>
        <b>یوزر:</b> <code><?= ADMIN_USER ?></code><br>
        <b>رمز:</b> <code><?= ADMIN_PASS ?></code><br><br>
        <b>📚 کتاب نصب شده:</b><br>
        • فیزیک یازدهم تجربی (ID=40) — ۳ فصل<br>
        • ریاضی یازدهم انسانی (ID=41) — ۴ فصل<br><br>
        <b>⚠️ بعد از نصب، فایل‌های زیر را حذف کنید:</b><br>
        • <code>install.php</code><br>
        • <code>install_physics11_manual.sql</code><br>
        • <code>create_admin_sql.php</code>
      </div>
      <a href="<?= BASE_URL ?>/" class="btn">رفتن به سایت</a>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
