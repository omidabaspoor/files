import json
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from athena_runtime.capsule import IntentCapsule

_FORBIDDEN = frozenset({"prompt", "code", "script", "command", "executable"})


def _has_forbidden(value: Any) -> bool:
    if isinstance(value, dict):
        return any(str(k).lower() in _FORBIDDEN or _has_forbidden(v) for k, v in value.items())
    if isinstance(value, list):
        return any(_has_forbidden(v) for v in value)
    return False


class PlanStep(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    step_id: str = Field(min_length=1, max_length=64)
    operation: str = Field(min_length=1, max_length=64)
    arguments: dict[str, Any]
    depends_on: tuple[str, ...] = ()
    estimated_cost: float = Field(ge=0)

    @field_validator("arguments")
    @classmethod
    def bounded_safe_arguments(cls, value: dict[str, Any]) -> dict[str, Any]:
        try:
            encoded = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            raise ValueError("arguments must be JSON") from exc
        if len(encoded.encode()) > 4096:
            raise ValueError("arguments too large")
        if _has_forbidden(value):
            raise ValueError("executable code or prompt is forbidden")
        return value


class Plan(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    steps: tuple[PlanStep, ...]

    @classmethod
    def validate_for(cls, steps: list[PlanStep], capsule: IntentCapsule) -> "Plan":
        if len(steps) > capsule.max_steps:
            raise ValueError("too many steps")
        ids = [s.step_id for s in steps]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate step id")
        known = set(ids)
        if any(not set(s.depends_on) <= known for s in steps):
            raise ValueError("unknown dependency")
        if any(s.operation not in capsule.plan_scope_operations for s in steps):
            raise ValueError("operation outside scope")
        graph = {s.step_id: set(s.depends_on) for s in steps}
        visiting: set[str] = set()
        done: set[str] = set()

        def visit(node: str) -> None:
            if node in visiting:
                raise ValueError("dependency cycle")
            if node in done:
                return
            visiting.add(node)
            for dep in graph[node]:
                visit(dep)
            visiting.remove(node)
            done.add(node)

        for node in graph:
            visit(node)
        return cls(steps=tuple(steps))
