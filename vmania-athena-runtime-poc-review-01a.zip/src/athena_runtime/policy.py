from datetime import UTC, datetime

from athena_runtime.capsule import IntentCapsule


class PolicyEngine:
    def __init__(self, known_versions: set[str], known_operations: set[str]) -> None:
        self._versions = frozenset(known_versions)
        self._operations = frozenset(known_operations)

    def effective_permissions(self, capsule: IntentCapsule) -> frozenset[str]:
        if capsule.expires_at <= datetime.now(UTC) or capsule.policy_version not in self._versions:
            return frozenset()
        sets = (
            capsule.requested_operations,
            capsule.task_allowed_operations,
            capsule.server_maximum_operations,
            capsule.plan_scope_operations,
        )
        if any(not values or not values <= self._operations for values in sets):
            return frozenset()
        return frozenset.intersection(*sets)
