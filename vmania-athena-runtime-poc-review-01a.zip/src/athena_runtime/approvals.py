import asyncio
import hashlib
import json
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict


def args_digest(arguments: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(arguments, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    ).hexdigest()


class Approval(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    run_id: str
    tool_call_id: str
    operation: str
    args_digest: str
    expires_at: datetime
    decision: Literal["once", "deny"]


class ApprovalStore:
    def __init__(self) -> None:
        self._items: dict[tuple[str, str, str, str], Approval] = {}
        self._lock = asyncio.Lock()

    async def add(self, item: Approval) -> None:
        async with self._lock:
            self._items[(item.run_id, item.tool_call_id, item.operation, item.args_digest)] = item

    async def consume(self, run_id: str, tool_call_id: str, operation: str, digest: str) -> bool:
        key = (run_id, tool_call_id, operation, digest)
        async with self._lock:
            item = self._items.get(key)
            if item is None or item.decision != "once" or item.expires_at <= datetime.now(UTC):
                return False
            del self._items[key]
            return True
