import asyncio
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class IdempotencyKey:
    workspace_id: str
    run_id: str
    tool_call_id: str
    operation: str


class ReservationState(StrEnum):
    RESERVED = "reserved"
    IN_PROGRESS = "in_progress"
    REPLAY = "replay"


@dataclass(frozen=True, slots=True)
class Reservation:
    state: ReservationState
    outcome: Any = None


class IdempotencyStore(Protocol):
    async def reserve(self, key: IdempotencyKey) -> Reservation: ...

    async def complete(self, key: IdempotencyKey, outcome: Any) -> None: ...

    async def release(self, key: IdempotencyKey) -> None: ...


class InMemoryIdempotencyStore:
    def __init__(self) -> None:
        self._records: dict[IdempotencyKey, Any] = {}
        self._lock = asyncio.Lock()
        self._pending = object()

    async def reserve(self, key: IdempotencyKey) -> Reservation:
        async with self._lock:
            if key not in self._records:
                self._records[key] = self._pending
                return Reservation(ReservationState.RESERVED)
            value = self._records[key]
            return (
                Reservation(ReservationState.IN_PROGRESS)
                if value is self._pending
                else Reservation(ReservationState.REPLAY, value)
            )

    async def complete(self, key: IdempotencyKey, outcome: Any) -> None:
        async with self._lock:
            self._records[key] = outcome

    async def release(self, key: IdempotencyKey) -> None:
        async with self._lock:
            if self._records.get(key) is self._pending:
                del self._records[key]
