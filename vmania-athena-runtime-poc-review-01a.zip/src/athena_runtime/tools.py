from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

from athena_runtime.approvals import ApprovalStore, args_digest
from athena_runtime.authorization import (
    AuthorizationDecision,
    AuthorizationWorker,
    authorize_fail_closed,
)
from athena_runtime.capsule import CapsuleVerifier, IntentCapsule
from athena_runtime.idempotency import IdempotencyKey, IdempotencyStore, ReservationState
from athena_runtime.policy import PolicyEngine

ToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


@dataclass(frozen=True, slots=True)
class ToolRequest:
    tool_call_id: str
    operation: str
    arguments: dict[str, Any]


class BrokerOutcomeStatus(StrEnum):
    DENIED = "denied"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    IN_PROGRESS = "in_progress"
    REPLAYED = "replayed"


@dataclass(frozen=True, slots=True)
class BrokerOutcome:
    status: BrokerOutcomeStatus
    detail: str
    result: dict[str, Any] | None = None


class ToolBroker:
    def __init__(
        self,
        verifier: CapsuleVerifier,
        policy: PolicyEngine,
        authorizer: AuthorizationWorker,
        approvals: ApprovalStore,
        idempotency: IdempotencyStore,
        authorization_timeout: float,
    ) -> None:
        self._verifier = verifier
        self._policy = policy
        self._authorizer = authorizer
        self._approvals = approvals
        self._idempotency = idempotency
        self._timeout = authorization_timeout
        self._handlers: dict[str, ToolHandler] = {}

    def register(self, operation: str, handler: ToolHandler) -> None:
        if operation not in {"allowed_canary", "forbidden_canary"}:
            raise ValueError("only fixed canaries may be registered")
        self._handlers[operation] = handler

    async def execute(self, capsule: IntentCapsule, request: ToolRequest) -> BrokerOutcome:
        try:
            verified = self._verifier.verify(capsule)
        except Exception:
            verified = False
        if verified is not True:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "capsule verification failed")
        if request.operation not in self._policy.effective_permissions(capsule):
            return BrokerOutcome(
                BrokerOutcomeStatus.DENIED, "operation outside effective permission"
            )
        decision = await authorize_fail_closed(self._authorizer, request, self._timeout)
        if decision is AuthorizationDecision.DENY:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "authorization denied")
        if decision is AuthorizationDecision.REQUIRE_APPROVAL and not await self._approvals.consume(
            capsule.run_id, request.tool_call_id, request.operation, args_digest(request.arguments)
        ):
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "valid one-time approval required")
        if (
            decision is not AuthorizationDecision.ALLOW
            and decision is not AuthorizationDecision.REQUIRE_APPROVAL
        ):
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "invalid authorization decision")
        handler = self._handlers.get(request.operation)
        if handler is None:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "handler unavailable")
        key = IdempotencyKey(
            capsule.workspace_id, capsule.run_id, request.tool_call_id, request.operation
        )
        reservation = await self._idempotency.reserve(key)
        if reservation.state is ReservationState.IN_PROGRESS:
            return BrokerOutcome(BrokerOutcomeStatus.IN_PROGRESS, "execution already reserved")
        if reservation.state is ReservationState.REPLAY:
            previous = reservation.outcome
            return BrokerOutcome(
                BrokerOutcomeStatus.REPLAYED,
                f"previous outcome: {previous.status}",
                previous.result,
            )
        try:
            result = await handler(request.arguments)
        except Exception as exc:
            outcome = BrokerOutcome(
                BrokerOutcomeStatus.FAILED, f"handler failed: {type(exc).__name__}"
            )
            await self._idempotency.complete(key, outcome)
            return outcome
        outcome = BrokerOutcome(BrokerOutcomeStatus.SUCCEEDED, "handler completed", result)
        await self._idempotency.complete(key, outcome)
        return outcome


def canary_handler(directory: Path) -> ToolHandler:
    async def handler(arguments: dict[str, Any]) -> dict[str, Any]:
        marker = directory / f"marker-{len(list(directory.iterdir()))}.txt"
        marker.write_text("canary", encoding="utf-8")
        return {"marker": marker.name}

    return handler
