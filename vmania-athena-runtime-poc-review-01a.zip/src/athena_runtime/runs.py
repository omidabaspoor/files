from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum

from athena_runtime.errors import InvalidTransition


class RunState(StrEnum):
    CREATED = "created"
    VALIDATING = "validating"
    NEEDS_CLARIFICATION = "needs_clarification"
    NEEDS_APPROVAL = "needs_approval"
    QUEUED = "queued"
    RUNNING = "running"
    QUALITY_CHECK = "quality_check"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"
    EXPIRED = "expired"
    BLOCKED = "blocked"


TERMINAL = frozenset(
    {RunState.COMPLETED, RunState.FAILED, RunState.STOPPED, RunState.EXPIRED, RunState.BLOCKED}
)
_TRANSITIONS = {
    RunState.CREATED: {RunState.VALIDATING, RunState.STOPPED, RunState.EXPIRED},
    RunState.VALIDATING: {
        RunState.NEEDS_CLARIFICATION,
        RunState.NEEDS_APPROVAL,
        RunState.QUEUED,
        RunState.FAILED,
        RunState.STOPPED,
        RunState.EXPIRED,
        RunState.BLOCKED,
    },
    RunState.NEEDS_CLARIFICATION: {RunState.VALIDATING, RunState.STOPPED, RunState.EXPIRED},
    RunState.NEEDS_APPROVAL: {
        RunState.QUEUED,
        RunState.STOPPED,
        RunState.EXPIRED,
        RunState.BLOCKED,
    },
    RunState.QUEUED: {RunState.RUNNING, RunState.STOPPED, RunState.EXPIRED, RunState.BLOCKED},
    RunState.RUNNING: {
        RunState.QUALITY_CHECK,
        RunState.FAILED,
        RunState.STOPPED,
        RunState.EXPIRED,
        RunState.BLOCKED,
    },
    RunState.QUALITY_CHECK: {
        RunState.COMPLETED,
        RunState.FAILED,
        RunState.STOPPED,
        RunState.BLOCKED,
    },
}


@dataclass(frozen=True, slots=True)
class RunTransitionEvent:
    run_id: str
    sequence: int
    from_state: RunState
    to_state: RunState
    occurred_at: datetime


@dataclass(slots=True)
class Run:
    run_id: str
    state: RunState = RunState.CREATED
    events: list[RunTransitionEvent] = field(default_factory=list)

    def transition(self, to_state: RunState) -> RunTransitionEvent:
        if to_state not in _TRANSITIONS.get(self.state, set()):
            raise InvalidTransition(f"invalid transition: {self.state} -> {to_state}")
        event = RunTransitionEvent(
            self.run_id, len(self.events) + 1, self.state, to_state, datetime.now(UTC)
        )
        self.state = to_state
        self.events.append(event)
        return event
