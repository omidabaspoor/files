class AthenaRuntimeError(Exception):
    """Base domain error."""


class InvalidTransition(AthenaRuntimeError):
    """A run state transition is not in the explicit graph."""
