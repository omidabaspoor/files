from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from athena_runtime.capsule import IntentCapsule
from athena_runtime.errors import InvalidTransition
from athena_runtime.plans import Plan, PlanStep
from athena_runtime.runs import Run, RunState


def capsule(**changes: object) -> IntentCapsule:
    data = dict(
        run_id="r1",
        workspace_id="w1",
        goal="test",
        requested_operations={"allowed_canary"},
        task_allowed_operations={"allowed_canary"},
        server_maximum_operations={"allowed_canary"},
        plan_scope_operations={"allowed_canary"},
        budget=10,
        max_steps=3,
        expires_at=datetime.now(UTC) + timedelta(minutes=5),
        nonce="n",
        policy_version="v1",
    )
    data.update(changes)
    return IntentCapsule(**data)


def test_success_path_and_monotonic_events() -> None:
    run = Run("r")
    for state in [
        RunState.VALIDATING,
        RunState.QUEUED,
        RunState.RUNNING,
        RunState.QUALITY_CHECK,
        RunState.COMPLETED,
    ]:
        run.transition(state)
    assert [e.sequence for e in run.events] == [1, 2, 3, 4, 5]
    assert all(e.run_id == "r" and e.occurred_at.tzinfo == UTC for e in run.events)


@pytest.mark.parametrize(
    "path",
    [
        [RunState.VALIDATING, RunState.NEEDS_CLARIFICATION, RunState.VALIDATING],
        [RunState.VALIDATING, RunState.NEEDS_APPROVAL, RunState.QUEUED],
        [RunState.VALIDATING, RunState.QUEUED, RunState.STOPPED],
        [RunState.VALIDATING, RunState.EXPIRED],
    ],
)
def test_explicit_branches(path: list[RunState]) -> None:
    run = Run("r")
    for state in path:
        run.transition(state)
    assert run.state == path[-1]


def test_invalid_and_terminal_reactivation() -> None:
    with pytest.raises(InvalidTransition):
        Run("r").transition(RunState.RUNNING)
    run = Run("r")
    run.transition(RunState.VALIDATING)
    run.transition(RunState.EXPIRED)
    with pytest.raises(InvalidTransition):
        run.transition(RunState.RUNNING)


def test_capsule_is_deeply_immutable_and_validated() -> None:
    cap = capsule()
    assert isinstance(cap.requested_operations, frozenset)
    with pytest.raises(ValidationError):
        cap.goal = "changed"  # type: ignore[misc]
    with pytest.raises(ValidationError):
        capsule(run_id="")
    with pytest.raises(ValidationError):
        capsule(budget=-1)
    with pytest.raises(ValidationError):
        capsule(max_steps=0)
    with pytest.raises(ValidationError):
        capsule(max_steps=101)


def test_plan_validation() -> None:
    cap = capsule(max_steps=2)
    plan = Plan.validate_for(
        [
            PlanStep(
                step_id="a",
                operation="allowed_canary",
                arguments={},
                depends_on=(),
                estimated_cost=1,
            ),
            PlanStep(
                step_id="b",
                operation="allowed_canary",
                arguments={},
                depends_on=("a",),
                estimated_cost=1,
            ),
        ],
        cap,
    )
    assert len(plan.steps) == 2
    with pytest.raises(ValueError):
        Plan.validate_for(
            [
                PlanStep(
                    step_id="a",
                    operation="forbidden_canary",
                    arguments={},
                    depends_on=(),
                    estimated_cost=0,
                )
            ],
            cap,
        )
    with pytest.raises(ValueError):
        Plan.validate_for(
            [
                PlanStep(
                    step_id="a",
                    operation="allowed_canary",
                    arguments={},
                    depends_on=("b",),
                    estimated_cost=0,
                )
            ],
            cap,
        )
    with pytest.raises(ValueError):
        Plan.validate_for(
            [
                PlanStep(
                    step_id="a",
                    operation="allowed_canary",
                    arguments={},
                    depends_on=("b",),
                    estimated_cost=0,
                ),
                PlanStep(
                    step_id="b",
                    operation="allowed_canary",
                    arguments={},
                    depends_on=("a",),
                    estimated_cost=0,
                ),
            ],
            cap,
        )
    with pytest.raises(ValidationError):
        PlanStep(
            step_id="a",
            operation="allowed_canary",
            arguments={"prompt": "evil"},
            depends_on=(),
            estimated_cost=0,
        )
