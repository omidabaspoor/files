import asyncio
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest

from athena_runtime.approvals import Approval, ApprovalStore, args_digest
from athena_runtime.authorization import AuthorizationDecision
from athena_runtime.capsule import IntentCapsule
from athena_runtime.idempotency import InMemoryIdempotencyStore
from athena_runtime.plans import Plan, PlanStep
from athena_runtime.policy import PolicyEngine
from athena_runtime.tools import BrokerOutcomeStatus, ToolBroker, ToolRequest, canary_handler


@pytest.fixture(autouse=True)
def cleanup_temp_markers(tmp_path: Path) -> Iterator[None]:
    yield
    for marker in tmp_path.glob("marker-*.txt"):
        marker.unlink()


class Verifier:
    def verify(self, capsule: IntentCapsule) -> bool:
        return True


class Authorizer:
    def __init__(
        self,
        result: Any = AuthorizationDecision.ALLOW,
        delay: float = 0,
        error: Exception | None = None,
    ):
        self.result, self.delay, self.error = result, delay, error

    async def authorize(self, request: object) -> Any:
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.error:
            raise self.error
        return self.result


def cap(run="r", **kw: object) -> IntentCapsule:
    d = dict(
        run_id=run,
        workspace_id="w",
        goal="g",
        requested_operations={"allowed_canary"},
        task_allowed_operations={"allowed_canary"},
        server_maximum_operations={"allowed_canary"},
        plan_scope_operations={"allowed_canary"},
        budget=1,
        max_steps=2,
        expires_at=datetime.now(UTC) + timedelta(minutes=2),
        nonce="n",
        policy_version="v1",
    )
    d.update(kw)
    return IntentCapsule(**d)


def broker(
    tmp_path: Path, authorizer: Authorizer, approvals: ApprovalStore | None = None, timeout=0.02
) -> ToolBroker:
    b = ToolBroker(
        Verifier(),
        PolicyEngine({"v1"}, {"allowed_canary", "forbidden_canary"}),
        authorizer,
        approvals or ApprovalStore(),
        InMemoryIdempotencyStore(),
        timeout,
    )
    b.register("allowed_canary", canary_handler(tmp_path))
    b.register("forbidden_canary", canary_handler(tmp_path))
    return b


async def invoke(
    b: ToolBroker,
    c: IntentCapsule,
    op="allowed_canary",
    call="c",
    args: dict[str, Any] | None = None,
):
    return await b.execute(c, ToolRequest(tool_call_id=call, operation=op, arguments=args or {}))


@pytest.mark.asyncio
async def test_s01_forbidden_tool_no_marker(tmp_path: Path):
    out = await invoke(broker(tmp_path, Authorizer()), cap(), "forbidden_canary")
    assert out.status is BrokerOutcomeStatus.DENIED and not list(tmp_path.iterdir())


@pytest.mark.asyncio
async def test_s02_authorizer_exception(tmp_path: Path):
    out = await invoke(broker(tmp_path, Authorizer(error=RuntimeError())), cap())
    assert out.status is BrokerOutcomeStatus.DENIED and not list(tmp_path.iterdir())


@pytest.mark.asyncio
async def test_s03_authorizer_timeout_stays_side_effect_free(tmp_path: Path):
    out = await invoke(broker(tmp_path, Authorizer(delay=0.1), timeout=0.005), cap())
    await asyncio.sleep(0.12)
    assert out.status is BrokerOutcomeStatus.DENIED and not list(tmp_path.iterdir())


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "change",
    [
        {"requested_operations": set()},
        {"policy_version": "x"},
        {"expires_at": datetime.now(UTC) - timedelta(seconds=1)},
        {"server_maximum_operations": set()},
    ],
)
async def test_s04_s05_s06_s07_policy_denials(tmp_path: Path, change: dict[str, Any]):
    out = await invoke(broker(tmp_path, Authorizer()), cap(**change))
    assert out.status is BrokerOutcomeStatus.DENIED and not list(tmp_path.iterdir())


@pytest.mark.asyncio
async def test_s08_s09_approval_binding(tmp_path: Path):
    for wrong_run, args in [(True, {"x": 1}), (False, {"x": 2})]:
        store = ApprovalStore()
        approved_args = {"x": 1}
        await store.add(
            Approval(
                run_id="other" if wrong_run else "r",
                tool_call_id="c",
                operation="allowed_canary",
                args_digest=args_digest(approved_args),
                expires_at=datetime.now(UTC) + timedelta(minutes=1),
                decision="once",
            )
        )
        out = await invoke(
            broker(tmp_path, Authorizer(AuthorizationDecision.REQUIRE_APPROVAL), store),
            cap(),
            args=args,
        )
        assert out.status is BrokerOutcomeStatus.DENIED
    assert not list(tmp_path.iterdir())


@pytest.mark.asyncio
async def test_s10_duplicate_marker_once(tmp_path: Path):
    b = broker(tmp_path, Authorizer())
    first = await invoke(b, cap())
    second = await invoke(b, cap())
    assert (
        first.status is BrokerOutcomeStatus.SUCCEEDED
        and second.status is BrokerOutcomeStatus.REPLAYED
        and len(list(tmp_path.iterdir())) == 1
    )


@pytest.mark.asyncio
async def test_s11_concurrent_policy_isolation(tmp_path: Path):
    tasks = []
    for i in range(20):
        allowed = i % 2 == 0
        c = cap(
            str(i), requested_operations={"allowed_canary"} if allowed else {"forbidden_canary"}
        )
        tasks.append(invoke(broker(tmp_path, Authorizer()), c, call=str(i)))
    outs = await asyncio.gather(*tasks)
    assert (
        sum(o.status is BrokerOutcomeStatus.SUCCEEDED for o in outs) == 10
        and len(list(tmp_path.iterdir())) == 10
    )


def test_s12_plan_cannot_add_operation():
    with pytest.raises(ValueError):
        Plan.validate_for(
            [
                PlanStep(
                    step_id="x",
                    operation="forbidden_canary",
                    arguments={},
                    depends_on=(),
                    estimated_cost=0,
                )
            ],
            cap(),
        )


def test_s13_terminal_cannot_run():
    from athena_runtime.errors import InvalidTransition
    from athena_runtime.runs import Run, RunState

    r = Run("r")
    r.transition(RunState.VALIDATING)
    r.transition(RunState.EXPIRED)
    with pytest.raises(InvalidTransition):
        r.transition(RunState.RUNNING)


@pytest.mark.asyncio
@pytest.mark.parametrize("bad", [None, "ALLOW"])
async def test_s14_invalid_authorization_result(tmp_path: Path, bad: Any):
    out = await invoke(broker(tmp_path, Authorizer(bad)), cap())
    assert out.status is BrokerOutcomeStatus.DENIED and not list(tmp_path.iterdir())


@pytest.mark.asyncio
async def test_s15_handler_exception_not_blindly_retried(tmp_path: Path):
    b = broker(tmp_path, Authorizer())
    calls = 0

    async def broken(args: dict[str, Any]) -> dict[str, Any]:
        nonlocal calls
        calls += 1
        raise RuntimeError("boom")

    b.register("allowed_canary", broken)
    one = await invoke(b, cap())
    two = await invoke(b, cap())
    assert (
        one.status is BrokerOutcomeStatus.FAILED
        and two.status is BrokerOutcomeStatus.REPLAYED
        and calls == 1
    )
