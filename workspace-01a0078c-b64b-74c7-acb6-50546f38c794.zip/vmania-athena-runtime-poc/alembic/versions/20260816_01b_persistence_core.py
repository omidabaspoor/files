"""Create Athena Runtime PostgreSQL persistence core.

Revision ID: 20260816_01b
Revises: None
"""

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from alembic import op

revision: str = "20260816_01b"
down_revision: str | None = None
branch_labels: str | None = None
depends_on: str | None = None

SCHEMA = "athena"
TABLES = (
    "runs",
    "run_events",
    "idempotency_records",
    "approvals",
    "outbox_events",
    "cost_reservations",
)
WORKSPACE_POLICY = "workspace_id = NULLIF(current_setting('app.workspace_id', true), '')::uuid"


def upgrade() -> None:
    op.create_table(
        "runs",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("state", sa.String(32), nullable=False),
        sa.Column("version", sa.BigInteger(), server_default=sa.text("0"), nullable=False),
        sa.Column("max_cost_microunits", sa.BigInteger(), nullable=False),
        sa.Column("max_steps", sa.Integer(), nullable=False),
        sa.Column("deadline_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.PrimaryKeyConstraint("id", name="pk_runs"),
        sa.UniqueConstraint("workspace_id", "id", name="uq_runs_workspace_id_id"),
        sa.CheckConstraint(
            "state IN ('created','validating','needs_clarification','needs_approval','queued',"
            "'running','quality_check','completed','failed','stopped','expired','blocked')",
            name="ck_runs_run_state",
        ),
        sa.CheckConstraint("version >= 0", name="ck_runs_run_version_nonnegative"),
        sa.CheckConstraint("max_cost_microunits >= 0", name="ck_runs_run_max_cost_nonnegative"),
        sa.CheckConstraint(
            "max_steps > 0 AND max_steps <= 100", name="ck_runs_run_max_steps_range"
        ),
        schema=SCHEMA,
    )
    op.create_index("ix_runs_workspace_state", "runs", ["workspace_id", "state"], schema=SCHEMA)

    op.create_table(
        "run_events",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("run_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("sequence", sa.BigInteger(), nullable=False),
        sa.Column("transition_version", sa.BigInteger(), nullable=True),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("visibility", sa.String(24), nullable=False),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["workspace_id", "run_id"],
            ["athena.runs.workspace_id", "athena.runs.id"],
            name="fk_run_events_workspace_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_run_events"),
        sa.UniqueConstraint("run_id", "sequence", name="uq_run_events_run_sequence"),
        sa.CheckConstraint("sequence > 0", name="ck_run_events_run_event_sequence_positive"),
        sa.CheckConstraint(
            "transition_version IS NULL OR transition_version > 0",
            name="ck_run_events_run_event_transition_version_positive",
        ),
        sa.CheckConstraint(
            "(event_type = 'run.transitioned' AND transition_version IS NOT NULL) OR "
            "(event_type <> 'run.transitioned' AND transition_version IS NULL)",
            name="ck_run_events_run_event_transition_binding",
        ),
        sa.CheckConstraint(
            "visibility IN ('internal','user','audit')",
            name="ck_run_events_run_event_visibility",
        ),
        sa.CheckConstraint(
            "octet_length(payload::text) <= 16384",
            name="ck_run_events_run_event_payload_size",
        ),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_run_events_workspace_run",
        "run_events",
        ["workspace_id", "run_id"],
        schema=SCHEMA,
    )
    op.create_index(
        "uq_run_events_transition_version",
        "run_events",
        ["run_id", "transition_version"],
        unique=True,
        postgresql_where=sa.text("transition_version IS NOT NULL"),
        schema=SCHEMA,
    )

    op.create_table(
        "idempotency_records",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("run_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("tool_call_id", sa.String(128), nullable=False),
        sa.Column("operation", sa.String(64), nullable=False),
        sa.Column("args_digest", sa.String(64), nullable=False),
        sa.Column("policy_version", sa.String(64), nullable=False),
        sa.Column("status", sa.String(48), nullable=False),
        sa.Column("outcome", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("error", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("lease_owner", sa.String(128), nullable=True),
        sa.Column("lease_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["workspace_id", "run_id"],
            ["athena.runs.workspace_id", "athena.runs.id"],
            name="fk_idempotency_workspace_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_idempotency_records"),
        sa.UniqueConstraint(
            "workspace_id",
            "run_id",
            "tool_call_id",
            "operation",
            name="uq_idempotency_business_key",
        ),
        sa.CheckConstraint(
            "status IN ('reserved','completed','failed','unknown_reconciliation_required')",
            name="ck_idempotency_records_idempotency_status",
        ),
        sa.CheckConstraint(
            "outcome IS NULL OR octet_length(outcome::text) <= 16384",
            name="ck_idempotency_records_idempotency_outcome_size",
        ),
        sa.CheckConstraint(
            "error IS NULL OR octet_length(error::text) <= 16384",
            name="ck_idempotency_records_idempotency_error_size",
        ),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_idempotency_workspace_lease",
        "idempotency_records",
        ["workspace_id", "status", "lease_expires_at"],
        schema=SCHEMA,
    )

    op.create_table(
        "approvals",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("run_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("tool_call_id", sa.String(128), nullable=False),
        sa.Column("operation", sa.String(64), nullable=False),
        sa.Column("args_digest", sa.String(64), nullable=False),
        sa.Column("decision", sa.String(16), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("consumed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["workspace_id", "run_id"],
            ["athena.runs.workspace_id", "athena.runs.id"],
            name="fk_approvals_workspace_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_approvals"),
        sa.UniqueConstraint(
            "workspace_id",
            "run_id",
            "tool_call_id",
            "operation",
            "args_digest",
            name="uq_approvals_binding",
        ),
        sa.CheckConstraint("decision IN ('once','deny')", name="ck_approvals_approval_decision"),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_approvals_workspace_run",
        "approvals",
        ["workspace_id", "run_id"],
        schema=SCHEMA,
    )

    op.create_table(
        "outbox_events",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("aggregate_type", sa.String(64), nullable=False),
        sa.Column("aggregate_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attempt_count", sa.Integer(), server_default=sa.text("0"), nullable=False),
        sa.Column("last_error_code", sa.String(64), nullable=True),
        sa.Column("claim_owner", sa.String(128), nullable=True),
        sa.Column("claim_expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(
            ["workspace_id", "aggregate_id"],
            ["athena.runs.workspace_id", "athena.runs.id"],
            name="fk_outbox_workspace_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_outbox_events"),
        sa.CheckConstraint("aggregate_type = 'run'", name="ck_outbox_events_outbox_run_aggregate"),
        sa.CheckConstraint(
            "attempt_count >= 0", name="ck_outbox_events_outbox_attempt_nonnegative"
        ),
        sa.CheckConstraint(
            "octet_length(payload::text) <= 16384",
            name="ck_outbox_events_outbox_payload_size",
        ),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_outbox_unpublished",
        "outbox_events",
        ["workspace_id", "published_at", "created_at"],
        schema=SCHEMA,
    )

    op.create_table(
        "cost_reservations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("workspace_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("run_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("reserved_microunits", sa.BigInteger(), nullable=False),
        sa.Column(
            "settled_microunits", sa.BigInteger(), server_default=sa.text("0"), nullable=False
        ),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("version", sa.BigInteger(), server_default=sa.text("0"), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(
            ["workspace_id", "run_id"],
            ["athena.runs.workspace_id", "athena.runs.id"],
            name="fk_cost_reservations_workspace_run",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_cost_reservations"),
        sa.UniqueConstraint("workspace_id", "run_id", name="uq_cost_reservations_workspace_run"),
        sa.CheckConstraint(
            "reserved_microunits >= 0",
            name="ck_cost_reservations_cost_reserved_nonnegative",
        ),
        sa.CheckConstraint(
            "settled_microunits >= 0",
            name="ck_cost_reservations_cost_settled_nonnegative",
        ),
        sa.CheckConstraint(
            "settled_microunits <= reserved_microunits",
            name="ck_cost_reservations_cost_settled_within_reserved",
        ),
        sa.CheckConstraint("version >= 0", name="ck_cost_reservations_cost_version_nonnegative"),
        sa.CheckConstraint(
            "status IN ('reserved','partially_settled','settled','released','disputed')",
            name="ck_cost_reservations_cost_status",
        ),
        schema=SCHEMA,
    )
    op.create_index(
        "ix_cost_workspace_run",
        "cost_reservations",
        ["workspace_id", "run_id"],
        schema=SCHEMA,
    )

    _install_security_and_functions()


def _install_security_and_functions() -> None:
    for table_name in TABLES:
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table_name}" OWNER TO athena_migration')
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table_name}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{SCHEMA}"."{table_name}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f"""
            CREATE POLICY {table_name}_workspace_isolation ON "{SCHEMA}"."{table_name}"
              FOR ALL TO athena_app, athena_migration
              USING ({WORKSPACE_POLICY})
              WITH CHECK ({WORKSPACE_POLICY})
            """
        )

    op.execute(
        """
        CREATE FUNCTION athena.enforce_run_state_transition() RETURNS trigger
        LANGUAGE plpgsql
        SET search_path = pg_catalog, athena
        AS $$
        BEGIN
          IF TG_OP = 'INSERT' THEN
            IF NEW.state <> 'created' OR NEW.version <> 0 THEN
              RAISE EXCEPTION 'run must start at created/version 0' USING ERRCODE = '23514';
            END IF;
            RETURN NEW;
          END IF;
          IF NEW.state = OLD.state THEN RETURN NEW; END IF;
          IF (OLD.state = 'created' AND NEW.state IN ('validating','stopped','expired'))
             OR (OLD.state = 'validating' AND NEW.state IN
                 ('needs_clarification','needs_approval','queued','failed','stopped','expired','blocked'))
             OR (OLD.state = 'needs_clarification' AND NEW.state IN
                 ('validating','stopped','expired'))
             OR (OLD.state = 'needs_approval' AND NEW.state IN
                 ('queued','stopped','expired','blocked'))
             OR (OLD.state = 'queued' AND NEW.state IN ('running','stopped','expired','blocked'))
             OR (OLD.state = 'running' AND NEW.state IN
                 ('quality_check','failed','stopped','expired','blocked'))
             OR (OLD.state = 'quality_check' AND NEW.state IN
                 ('completed','failed','stopped','blocked')) THEN
            RETURN NEW;
          END IF;
          RAISE EXCEPTION 'invalid run state transition: % -> %', OLD.state, NEW.state
            USING ERRCODE = '23514';
        END $$;

        CREATE TRIGGER trg_run_state_transition
          BEFORE INSERT OR UPDATE OF state ON athena.runs
          FOR EACH ROW EXECUTE FUNCTION athena.enforce_run_state_transition();

        CREATE FUNCTION athena.enforce_run_event_sequence() RETURNS trigger
        LANGUAGE plpgsql
        SET search_path = pg_catalog, athena
        AS $$
        DECLARE expected_sequence bigint;
        BEGIN
          PERFORM pg_advisory_xact_lock(hashtextextended(NEW.run_id::text, 0));
          SELECT COALESCE(MAX(sequence), 0) + 1 INTO expected_sequence
            FROM athena.run_events WHERE run_id = NEW.run_id;
          IF NEW.sequence <> expected_sequence THEN
            RAISE EXCEPTION 'run event sequence gap or duplicate' USING ERRCODE = '23514';
          END IF;
          RETURN NEW;
        END $$;

        CREATE TRIGGER trg_run_event_sequence
          BEFORE INSERT ON athena.run_events
          FOR EACH ROW EXECUTE FUNCTION athena.enforce_run_event_sequence();

        CREATE FUNCTION athena.transition_run(
          p_run_id uuid,
          p_expected_version bigint,
          p_from_state text,
          p_to_state text,
          p_occurred_at timestamptz,
          p_outbox_payload jsonb
        ) RETURNS bigint
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, athena
        AS $$
        DECLARE
          v_workspace uuid;
          v_new_version bigint;
          v_sequence bigint;
          v_event_id uuid := gen_random_uuid();
        BEGIN
          v_workspace := NULLIF(current_setting('app.workspace_id', true), '')::uuid;
          IF v_workspace IS NULL OR p_occurred_at IS NULL OR p_outbox_payload IS NULL THEN
            RAISE EXCEPTION 'missing transition context' USING ERRCODE = '22023';
          END IF;
          UPDATE athena.runs
             SET state = p_to_state, version = version + 1, updated_at = now()
           WHERE id = p_run_id AND workspace_id = v_workspace
             AND version = p_expected_version AND state = p_from_state
           RETURNING version INTO v_new_version;
          IF NOT FOUND THEN
            RAISE EXCEPTION 'stale or invisible run' USING ERRCODE = '40001';
          END IF;
          SELECT COALESCE(MAX(sequence), 0) + 1 INTO v_sequence
            FROM athena.run_events WHERE run_id = p_run_id;
          INSERT INTO athena.run_events(
            id, workspace_id, run_id, sequence, transition_version,
            event_type, visibility, payload, occurred_at
          ) VALUES (
            v_event_id, v_workspace, p_run_id, v_sequence, v_new_version,
            'run.transitioned', 'internal',
            jsonb_build_object('from_state', p_from_state, 'to_state', p_to_state),
            p_occurred_at
          );
          INSERT INTO athena.outbox_events(
            id, workspace_id, aggregate_type, aggregate_id, event_type, payload
          ) VALUES (
            gen_random_uuid(), v_workspace, 'run', p_run_id, 'run.transitioned',
            p_outbox_payload || jsonb_build_object('event_id', v_event_id::text)
          );
          RETURN v_new_version;
        END $$;
        """
    )
    op.execute("ALTER FUNCTION athena.enforce_run_state_transition() OWNER TO athena_migration")
    op.execute("ALTER FUNCTION athena.enforce_run_event_sequence() OWNER TO athena_migration")
    op.execute(
        "ALTER FUNCTION athena.transition_run(uuid,bigint,text,text,timestamptz,jsonb) "
        "OWNER TO athena_migration"
    )
    op.execute(
        "REVOKE ALL ON FUNCTION "
        "athena.transition_run(uuid,bigint,text,text,timestamptz,jsonb) FROM PUBLIC"
    )
    op.execute(
        "GRANT EXECUTE ON FUNCTION "
        "athena.transition_run(uuid,bigint,text,text,timestamptz,jsonb) TO athena_app"
    )

    op.execute("GRANT USAGE ON SCHEMA athena TO athena_app")
    op.execute("GRANT SELECT, INSERT ON athena.runs TO athena_app")
    op.execute("GRANT SELECT, INSERT ON athena.run_events TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON athena.idempotency_records TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON athena.approvals TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON athena.outbox_events TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON athena.cost_reservations TO athena_app")


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS trg_run_event_sequence ON athena.run_events")
    op.execute("DROP TRIGGER IF EXISTS trg_run_state_transition ON athena.runs")
    op.execute(
        "DROP FUNCTION IF EXISTS athena.transition_run(uuid,bigint,text,text,timestamptz,jsonb)"
    )
    op.execute("DROP FUNCTION IF EXISTS athena.enforce_run_event_sequence()")
    op.execute("DROP FUNCTION IF EXISTS athena.enforce_run_state_transition()")

    op.drop_index("ix_cost_workspace_run", table_name="cost_reservations", schema=SCHEMA)
    op.drop_table("cost_reservations", schema=SCHEMA)
    op.drop_index("ix_outbox_unpublished", table_name="outbox_events", schema=SCHEMA)
    op.drop_table("outbox_events", schema=SCHEMA)
    op.drop_index("ix_approvals_workspace_run", table_name="approvals", schema=SCHEMA)
    op.drop_table("approvals", schema=SCHEMA)
    op.drop_index(
        "ix_idempotency_workspace_lease",
        table_name="idempotency_records",
        schema=SCHEMA,
    )
    op.drop_table("idempotency_records", schema=SCHEMA)
    op.drop_index("uq_run_events_transition_version", table_name="run_events", schema=SCHEMA)
    op.drop_index("ix_run_events_workspace_run", table_name="run_events", schema=SCHEMA)
    op.drop_table("run_events", schema=SCHEMA)
    op.drop_index("ix_runs_workspace_state", table_name="runs", schema=SCHEMA)
    op.drop_table("runs", schema=SCHEMA)
