"""Create Athena Runtime PostgreSQL persistence core.

Revision ID: 20260816_01b
Revises: None
"""

from alembic import op
from athena_runtime.persistence.schema import metadata

revision: str = "20260816_01b"
down_revision: str | None = None
branch_labels: str | None = None
depends_on: str | None = None

_TABLES = (
    "runs",
    "run_events",
    "idempotency_records",
    "approvals",
    "outbox_events",
    "cost_reservations",
)


def upgrade() -> None:
    op.execute(
        """
        DO $$ BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_migration') THEN
            CREATE ROLE athena_migration NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE
              NOINHERIT NOBYPASSRLS;
          END IF;
          IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_app') THEN
            CREATE ROLE athena_app NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE
              NOINHERIT NOBYPASSRLS;
          END IF;
        END $$;
        ALTER ROLE athena_app NOBYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE NOLOGIN;
        ALTER ROLE athena_migration NOBYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE NOLOGIN;
        """
    )
    metadata.create_all(bind=op.get_bind(), checkfirst=False)

    for table_name in _TABLES:
        op.execute(f'ALTER TABLE "{table_name}" OWNER TO athena_migration')
        op.execute(f'ALTER TABLE "{table_name}" ENABLE ROW LEVEL SECURITY')
        op.execute(f'ALTER TABLE "{table_name}" FORCE ROW LEVEL SECURITY')
        op.execute(
            f"""
            CREATE POLICY {table_name}_workspace_isolation ON "{table_name}"
              FOR ALL TO athena_app
              USING (
                workspace_id = NULLIF(current_setting('app.workspace_id', true), '')::uuid
              )
              WITH CHECK (
                workspace_id = NULLIF(current_setting('app.workspace_id', true), '')::uuid
              )
            """
        )

    op.execute(
        """
        CREATE FUNCTION athena_enforce_run_event_sequence() RETURNS trigger
        LANGUAGE plpgsql AS $$
        DECLARE expected_sequence bigint;
        BEGIN
          PERFORM pg_advisory_xact_lock(hashtextextended(NEW.run_id::text, 0));
          SELECT COALESCE(MAX(sequence), 0) + 1 INTO expected_sequence
            FROM run_events WHERE run_id = NEW.run_id;
          IF NEW.sequence <> expected_sequence THEN
            RAISE EXCEPTION 'run event sequence gap or duplicate'
              USING ERRCODE = '23514';
          END IF;
          RETURN NEW;
        END $$;

        CREATE TRIGGER trg_run_event_sequence
          BEFORE INSERT ON run_events
          FOR EACH ROW EXECUTE FUNCTION athena_enforce_run_event_sequence();

        CREATE FUNCTION athena_prevent_terminal_reactivation() RETURNS trigger
        LANGUAGE plpgsql AS $$
        BEGIN
          IF OLD.state IN ('completed','failed','stopped','expired','blocked')
             AND NEW.state <> OLD.state THEN
            RAISE EXCEPTION 'terminal run cannot transition'
              USING ERRCODE = '23514';
          END IF;
          RETURN NEW;
        END $$;

        CREATE TRIGGER trg_terminal_run
          BEFORE UPDATE ON runs
          FOR EACH ROW EXECUTE FUNCTION athena_prevent_terminal_reactivation();
        """
    )

    op.execute("GRANT USAGE ON SCHEMA public TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON runs TO athena_app")
    op.execute("GRANT SELECT, INSERT ON run_events TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON idempotency_records TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON approvals TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON outbox_events TO athena_app")
    op.execute("GRANT SELECT, INSERT, UPDATE ON cost_reservations TO athena_app")


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS trg_terminal_run ON runs")
    op.execute("DROP TRIGGER IF EXISTS trg_run_event_sequence ON run_events")
    op.execute("DROP FUNCTION IF EXISTS athena_prevent_terminal_reactivation()")
    op.execute("DROP FUNCTION IF EXISTS athena_enforce_run_event_sequence()")
    metadata.drop_all(bind=op.get_bind(), checkfirst=False)
    op.execute(
        """
        REVOKE USAGE ON SCHEMA public FROM athena_app;
        DO $$ BEGIN
          IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_app') THEN
            DROP ROLE athena_app;
          END IF;
          IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'athena_migration') THEN
            DROP ROLE athena_migration;
          END IF;
        END $$;
        """
    )
