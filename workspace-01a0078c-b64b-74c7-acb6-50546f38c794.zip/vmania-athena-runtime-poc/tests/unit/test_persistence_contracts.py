from datetime import UTC, datetime
from uuid import uuid4

import pytest

from athena_runtime.clocks import FakeClock
from athena_runtime.persistence.context import WorkspaceContextFactory
from athena_runtime.persistence.limits import MAX_JSON_BYTES, validate_json_payload
from athena_runtime.persistence.schema import metadata
from athena_runtime.runs import Run, RunState, RunTransitionEvent


def test_persistence_schema_has_exact_scoped_tables() -> None:
    assert set(metadata.tables) == {
        "runs",
        "run_events",
        "idempotency_records",
        "approvals",
        "outbox_events",
        "cost_reservations",
    }
    for table in metadata.tables.values():
        assert not table.c.workspace_id.nullable


def test_payload_limit_is_enforced() -> None:
    assert validate_json_payload({"ok": True}) == {"ok": True}
    with pytest.raises(ValueError, match="payload"):
        validate_json_payload({"value": "x" * MAX_JSON_BYTES})


@pytest.mark.asyncio
async def test_workspace_context_requires_program_authorization() -> None:
    workspace_id = uuid4()

    class DenyAuthorizer:
        async def authorize_workspace(self, principal_id: str, requested: object) -> bool:
            return False

    factory = WorkspaceContextFactory(DenyAuthorizer())
    with pytest.raises(PermissionError):
        await factory.create("principal", workspace_id)


def test_run_rehydrate_validates_sequence_and_terminal_state() -> None:
    now = datetime(2026, 1, 1, tzinfo=UTC)
    events = (
        RunTransitionEvent("r", 1, RunState.CREATED, RunState.VALIDATING, now),
        RunTransitionEvent("r", 2, RunState.VALIDATING, RunState.EXPIRED, now),
    )
    run = Run.rehydrate("r", RunState.EXPIRED, events, clock=FakeClock(now))
    assert run.state is RunState.EXPIRED
    assert run.events == events
    with pytest.raises(ValueError, match="sequence"):
        Run.rehydrate("r", RunState.EXPIRED, (events[1],), clock=FakeClock(now))
    with pytest.raises(ValueError, match="final state"):
        Run.rehydrate("r", RunState.RUNNING, events, clock=FakeClock(now))
