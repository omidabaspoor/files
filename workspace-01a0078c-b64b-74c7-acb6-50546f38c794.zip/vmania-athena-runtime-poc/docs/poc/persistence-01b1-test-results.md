# Persistence 01B.1 — Test Results

تاریخ: 2026-08-16

## Stage zero

```text
pytest -q -m "not integration"
48 passed, 22 deselected
```

Editable install پیش از F01 مطابق Review شکست خورد:

```text
ValueError: Unable to determine which files to ship inside the wheel
error: metadata-generation-failed
```

Integration در مرحله صفر بدون Database اجرا نشد.

## Final static/unit result

```text
pytest -q -m "not integration"
50 passed, 28 deselected

pytest -q -m integration
28 skipped, 50 deselected
Reason: BLOCKED_NOT_RUN — migration/runtime PostgreSQL DSN unavailable

ruff check .
All checks passed!

python -m compileall -q src tests alembic
PASS
```

48 تست قبلی PASS باقی ماندند و دو تست Unit جدید P23/P24 اضافه شدند.

## Packaging

| Check | Result |
|---|---|
| `pip install -e '.[dev]'` | PASS |
| `python -m build --wheel` | PASS |
| Wheel artifact | `vmania_athena_runtime_poc-0.1.0-py3-none-any.whl` |
| Install wheel in temporary venv | PASS |
| Import `athena_runtime` from wheel venv | PASS |
| Import `athena_runtime.persistence.schema` | PASS |

`build>=1.2,<2` فقط Development dependency استاندارد PEP 517 است.

## Migration static checks

- Revision reference به `metadata.create_all`: ندارد.
- Revision reference به `metadata.drop_all`: ندارد.
- `CREATE ROLE`/`DROP ROLE` در Revision: ندارد.
- Explicit `op.create_table/op.drop_table`: دارد.
- Offline PostgreSQL upgrade SQL generation: PASS.
- Offline PostgreSQL downgrade SQL generation: PASS.
- اجرای Migration روی Database واقعی: **BLOCKED_NOT_RUN**.

## F01–F09

| Finding | Static/Unit status | PostgreSQL proof |
|---|---|---|
| F01 Packaging | PASS | نیاز ندارد |
| F02 Runtime Login واقعی | IMPLEMENTED | BLOCKED_NOT_RUN — P25/P26 |
| F03 Role lifecycle جدا | PASS_STATIC | Bootstrap اجرا نشده |
| F04 Migration صریح | PASS_STATIC — P23 | Up/Down واقعی Blocked |
| F05 Live Action event model | PASS_UNIT — P24 | BLOCKED_NOT_RUN — P27 |
| F06 occurred_at | PASS_UNIT — P24 | BLOCKED_NOT_RUN — P27 |
| F07 single cost source | PASS_STATIC | DB execution Blocked |
| F08 one reservation per Run | IMPLEMENTED | BLOCKED_NOT_RUN — P28 |
| F09 transition function/trigger | PASS_STATIC | BLOCKED_NOT_RUN — P29/P30 |

## Integration tests blocked

- قبلی: P01–P22
- جدید:
  - P25: `session_user=athena_runtime_login`، `current_user=athena_app`، no superuser/BYPASSRLS/table ownership
  - P26: RESET ROLE هیچ table access نداشته باشد
  - P27: transition/live/transition با global sequence 1,2,3 و transition version 1,2 و occurred_at preserved
  - P28: cost reservation دوم برای Run رد شود
  - P29: direct App Role state update، مجاز یا نامجاز، رد شود و service path کار کند
  - P30: trigger، transition نامعتبر Migration Owner را رد کند

جمع Integration تعریف‌شده: **28**  
اجراشده: **0**  
Blocked/Skipped: **28**

## CI

Python 3.12/3.13 + PostgreSQL 17 + role bootstrap + Migration DSN + Runtime DSN + Integration + downgrade/upgrade + wheel checks در Workflow تعریف شده است. GitHub Actions در این محیط اجرا نشده است.
