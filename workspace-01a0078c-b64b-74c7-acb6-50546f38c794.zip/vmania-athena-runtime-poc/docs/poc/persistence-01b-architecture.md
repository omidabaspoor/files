# Athena Runtime PostgreSQL Persistence Core — 01B

## Scope

این مرحله فقط Persistence Core شش جدول را اضافه می‌کند. PostgreSQL منبع حقیقت Persistence است؛ API، SSE، Worker/Dispatcher، Model، Memory، User/Auth کامل، Wallet/Ledger نهایی و Tool واقعی وجود ندارند.

## Components

- `persistence/schema.py`: SQLAlchemy 2 Core metadata برای شش جدول PostgreSQL-only.
- `persistence/context.py`: صدور Context پس از Authorization برنامه و Transaction-scoped `set_config('app.workspace_id', ..., true)` معادل `SET LOCAL`.
- `persistence/repositories.py`: Run/Event transaction، durable idempotency، durable approval، outbox claim و cost reservation.
- `alembic/versions/20260816_01b_persistence_core.py`: Migration صریح و برگشت‌پذیر برای Table، Grant، RLS/FORCE RLS، function و trigger؛ Role lifecycle جداست.
- `compose.yaml`: تعریف PostgreSQL 17 محلی بدون Credential ذخیره‌شده.

## ERD محدود

```mermaid
erDiagram
    RUNS ||--o{ RUN_EVENTS : emits
    RUNS ||--o{ IDEMPOTENCY_RECORDS : deduplicates
    RUNS ||--o{ APPROVALS : authorizes
    RUNS ||--o{ COST_RESERVATIONS : reserves
    RUNS ||--o{ OUTBOX_EVENTS : publishes

    RUNS {
      uuid id PK
      uuid workspace_id
      string state
      bigint version
      bigint max_cost_microunits
      integer max_steps
      timestamptz deadline_at
    }
    RUN_EVENTS {
      uuid id PK
      uuid workspace_id FK
      uuid run_id FK
      bigint sequence UK
      bigint transition_version UK
      string event_type
      string visibility
      jsonb payload
      timestamptz occurred_at
      timestamptz created_at
    }
    IDEMPOTENCY_RECORDS {
      uuid id PK
      uuid workspace_id FK
      uuid run_id FK
      string tool_call_id
      string operation
      string args_digest
      string policy_version
      string status
      jsonb outcome
      string lease_owner
      timestamptz lease_expires_at
    }
    APPROVALS {
      uuid id PK
      uuid workspace_id FK
      uuid run_id FK
      string tool_call_id
      string operation
      string args_digest
      string decision
      timestamptz expires_at
      timestamptz consumed_at
    }
    OUTBOX_EVENTS {
      uuid id PK
      uuid workspace_id
      string aggregate_type
      uuid aggregate_id
      string event_type
      jsonb payload
      timestamptz published_at
      string claim_owner
      timestamptz claim_expires_at
    }
    COST_RESERVATIONS {
      uuid id PK
      uuid workspace_id FK
      uuid run_id FK
      bigint reserved_microunits
      bigint settled_microunits
      string status
      bigint version
    }
```

تمام جدول‌ها `workspace_id UUID NOT NULL`، UUID تصادفی، constraint و index صریح دارند. زمان‌ها `TIMESTAMPTZ` و `created_at`ها با `now()` پایگاه داده ساخته می‌شوند. Payload/Outcome در Application و Check Constraint پایگاه داده سقف 16 KiB دارند.

## Workspace/RLS boundary

1. `WorkspaceContextFactory` فقط پس از پاسخ مثبت `WorkspaceAuthorizer` یک Context می‌سازد.
2. Repository raw workspace string نمی‌پذیرد؛ `WorkspaceContext` می‌گیرد.
3. `WorkspaceTransactionManager` ابتدا Transaction را باز می‌کند، در تست Role منطقی `athena_app` را `SET LOCAL ROLE` می‌کند، سپس workspace را با `set_config(..., true)` محلی تنظیم می‌کند.
4. همه Repository queryها علاوه بر RLS، predicate صریح workspace دارند.
5. پایان Commit/Rollback مقدار local را پاک می‌کند؛ Connection pool نباید Context قبلی را نگه دارد.
6. Policy هر شش جدول از `current_setting('app.workspace_id', true)` استفاده می‌کند. Context مفقود برابر NULL و نتیجه صفر است؛ مقدار نامعتبر خطا و Fail-closed می‌دهد.

Roleها:

- `athena_migration`: مالک Schema/Table، `NOLOGIN`, `NOSUPERUSER`, `NOBYPASSRLS`.
- `athena_app`: Policy Role، مالک نیست، `NOLOGIN`, `NOSUPERUSER`, `NOBYPASSRLS`.
- `athena_runtime_login`: Login غیرمالک و بدون privilege مستقیم، `NOINHERIT`, `NOSUPERUSER`, `NOBYPASSRLS` و عضو `athena_app`.

RLS و `FORCE ROW LEVEL SECURITY` روی هر شش جدول فعال می‌شوند. Roleها با bootstrap جدا و password از Environment provision می‌شوند.

## Atomic run transition

```text
BEGIN
→ SET LOCAL ROLE / workspace context
→ Load run + ordered events
→ Run.rehydrate() validation
→ Domain transition
→ call SECURITY DEFINER athena.transition_run with fixed search_path
→ UPDATE runs WHERE version/state/workspace = expected
→ allocate global event sequence under Run lock
→ INSERT transition-versioned run_event with occurred_at
→ INSERT outbox_event
→ COMMIT
```

هر Exception کل Transaction را Rollback می‌کند. `Run.rehydrate` run ID، sequence پیوسته از 1، state chain، transition graph، timezone و final state را validate می‌کند. Trigger پایگاه داده reactivation از terminal state و sequence gap/duplicate را نیز رد می‌کند.

## Durable idempotency

Business key همان `(workspace_id, run_id, tool_call_id, operation)` است. Insert با PostgreSQL `ON CONFLICT DO NOTHING` انجام می‌شود. Record موجود با `FOR UPDATE` خوانده می‌شود:

- fingerprint متفاوت → `CONFLICT`
- completed/failed → structured replay
- lease فعال → `IN_PROGRESS`
- lease منقضی → atomically `unknown_reconciliation_required`

Lease منقضی هیچ‌گاه Reserve جدید یا اجرای خودکار Side Effect ایجاد نمی‌کند.

## Approval, Outbox, Cost

- Approval consume یک `UPDATE ... WHERE consumed_at IS NULL AND expires_at > now() AND decision='once' RETURNING` است؛ بنابراین تنها یک winner دارد.
- Outbox claim از `FOR UPDATE SKIP LOCKED` و claim lease استفاده می‌کند. Event ID کلید dedupe سمت Consumer آینده است؛ Dispatcher ساخته نشده است.
- Cost API به‌صورت `settle_to(total)` طراحی شده تا تکرار همان total idempotent باشد. Overrun، کاهش settlement، double settle و release نامعتبر رد می‌شوند. این جدول Wallet/Ledger نهایی نیست.
