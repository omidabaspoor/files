# vmania Athena Runtime PoC

A deliberately small, fail-closed domain and security kernel for Athena Runtime. This repository contains no API, database, network access, model adapter, worker, UI, dynamic plugins, or production tools.

## Scope proved

- Explicit run state machine and sequenced UTC domain events
- Frozen intent capsules with immutable operation sets
- Four-way permission intersection and deny-all policy failure behavior
- Cancellable async authorization with three decisions
- Fixed canary tool broker, one-time approvals, and atomic in-memory idempotency
- Bounded, acyclic, structured plan schema
- Security scenarios S01–S15, including 20 concurrent isolated runs

## Commands

```bash
python -m pip install -e '.[dev]'
pytest -q
ruff check .
python -m compileall -q src tests
```

Python 3.12+ is required. Runtime dependencies are Pydantic 2, SQLAlchemy 2 async, asyncpg, and Alembic. Development dependencies are pytest, pytest-asyncio, Ruff, and Build.

## PostgreSQL persistence 01B

The optional persistence core targets PostgreSQL 17 only. It requires an externally supplied test URL; SQLite is not supported.

```bash
pytest -q -m "not integration"
# Admin/bootstrap connection:
export ATHENA_MIGRATION_DATABASE_URL='postgresql+asyncpg://...'
# Non-superuser athena_runtime_login connection:
export ATHENA_TEST_DATABASE_URL='postgresql+asyncpg://...'
# Password is supplied only through the environment to psql bootstrap:
psql "$ADMIN_PSQL_URL" -f scripts/bootstrap_test_roles.sql
alembic upgrade head
pytest -q -m integration
```

Local PostgreSQL can be defined with `compose.yaml` after setting `ATHENA_POSTGRES_PASSWORD`; no credential is stored in this repository.

See `docs/poc/architecture.md`, `docs/poc/decisions.md`, `docs/poc/test-results.md`, and the `persistence-01b-*` reports.
