class PersistenceError(Exception):
    """Base persistence boundary error."""


class OptimisticLockError(PersistenceError):
    """The persisted version no longer matches the caller version."""


class EventSequenceError(PersistenceError):
    """An event sequence is duplicated or contains a gap."""


class CostReservationError(PersistenceError):
    """A cost reservation invariant was violated."""


class RecordNotFoundError(PersistenceError):
    """The workspace-scoped record was not visible."""
