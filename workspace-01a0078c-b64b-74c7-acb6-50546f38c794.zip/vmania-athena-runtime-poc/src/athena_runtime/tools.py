from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, ValidationError

from athena_runtime.approvals import ApprovalStore
from athena_runtime.authorization import (
    AuthorizationDecision,
    AuthorizationWorker,
    authorize_fail_closed,
)
from athena_runtime.capsule import CapsuleVerifier, IntentCapsule
from athena_runtime.errors import AthenaRuntimeError, IdempotencyConflict
from athena_runtime.idempotency import (
    IdempotencyKey,
    IdempotencyStore,
    RequestFingerprint,
    ReservationState,
)
from athena_runtime.json_snapshot import (
    canonical_json_bytes,
    fresh_json_object,
    snapshot_digest,
)
from athena_runtime.policy import PolicyEngine

ToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


@dataclass(frozen=True, slots=True, init=False)
class ToolRequest:
    tool_call_id: str
    operation: str
    canonical_arguments: bytes
    args_digest: str

    def __init__(self, tool_call_id: str, operation: str, arguments: dict[str, Any]) -> None:
        if not tool_call_id or not operation:
            raise ValueError("tool_call_id and operation are required")
        snapshot = canonical_json_bytes(arguments)
        object.__setattr__(self, "tool_call_id", tool_call_id)
        object.__setattr__(self, "operation", operation)
        object.__setattr__(self, "canonical_arguments", snapshot)
        object.__setattr__(self, "args_digest", snapshot_digest(snapshot))

    def fresh_arguments(self) -> dict[str, Any]:
        return fresh_json_object(self.canonical_arguments)


@dataclass(frozen=True, slots=True)
class AuthorizationRequest:
    run_id: str
    workspace_id: str
    tool_call_id: str
    operation: str
    args_digest: str
    policy_version: str


@dataclass(frozen=True, slots=True)
class ToolDefinition:
    operation: str
    input_model: type[BaseModel]
    handler: ToolHandler


class CanaryInput(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    value: int | None = None


class BrokerOutcomeStatus(StrEnum):
    DENIED = "denied"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    IN_PROGRESS = "in_progress"
    REPLAYED = "replayed"
    IDEMPOTENCY_CONFLICT = "idempotency_conflict"
    RECONCILIATION_REQUIRED = "reconciliation_required"


@dataclass(frozen=True, slots=True)
class BrokerOutcome:
    status: BrokerOutcomeStatus
    detail: str
    result: dict[str, Any] | None = None
    error: AthenaRuntimeError | None = None


class ToolBroker:
    def __init__(
        self,
        verifier: CapsuleVerifier,
        policy: PolicyEngine,
        authorizer: AuthorizationWorker,
        approvals: ApprovalStore,
        idempotency: IdempotencyStore,
        authorization_timeout: float,
    ) -> None:
        self._verifier = verifier
        self._policy = policy
        self._authorizer = authorizer
        self._approvals = approvals
        self._idempotency = idempotency
        self._timeout = authorization_timeout
        self._definitions: dict[str, ToolDefinition] = {}

    def register(self, definition: ToolDefinition) -> None:
        if definition.operation not in {"allowed_canary", "forbidden_canary"}:
            raise ValueError("only fixed canaries may be registered")
        if definition.input_model is not CanaryInput:
            raise ValueError("canary operations require the fixed CanaryInput schema")
        self._definitions[definition.operation] = definition

    async def execute(self, capsule: IntentCapsule, request: ToolRequest) -> BrokerOutcome:
        try:
            verified = self._verifier.verify(capsule)
        except Exception:
            verified = False
        if verified is not True:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "capsule verification failed")

        if snapshot_digest(request.canonical_arguments) != request.args_digest:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "request snapshot integrity failed")

        effective_permissions = self._policy.effective_permissions(capsule)
        if request.operation not in effective_permissions:
            return BrokerOutcome(
                BrokerOutcomeStatus.DENIED, "operation outside effective permission"
            )

        definition = self._definitions.get(request.operation)
        if definition is None:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "handler unavailable")
        try:
            validated_input = definition.input_model.model_validate(request.fresh_arguments())
        except ValidationError:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "tool arguments invalid")

        authorization_request = AuthorizationRequest(
            capsule.run_id,
            capsule.workspace_id,
            request.tool_call_id,
            request.operation,
            request.args_digest,
            capsule.policy_version,
        )
        decision = await authorize_fail_closed(
            self._authorizer, authorization_request, self._timeout
        )
        if decision is AuthorizationDecision.DENY:
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "authorization denied")
        if decision is AuthorizationDecision.REQUIRE_APPROVAL and not await self._approvals.consume(
            capsule.run_id,
            request.tool_call_id,
            request.operation,
            request.args_digest,
        ):
            return BrokerOutcome(BrokerOutcomeStatus.DENIED, "valid one-time approval required")

        key = IdempotencyKey(
            capsule.workspace_id, capsule.run_id, request.tool_call_id, request.operation
        )
        fingerprint = RequestFingerprint(request.args_digest, capsule.policy_version)
        reservation = await self._idempotency.reserve(key, fingerprint)
        if reservation.state is ReservationState.CONFLICT:
            error = IdempotencyConflict("key reused with different args or policy version")
            return BrokerOutcome(
                BrokerOutcomeStatus.IDEMPOTENCY_CONFLICT,
                str(error),
                error=error,
            )
        if reservation.state is ReservationState.UNKNOWN_RECONCILIATION_REQUIRED:
            return BrokerOutcome(
                BrokerOutcomeStatus.RECONCILIATION_REQUIRED,
                "expired lease requires reconciliation before retry",
            )
        if reservation.state is ReservationState.IN_PROGRESS:
            return BrokerOutcome(BrokerOutcomeStatus.IN_PROGRESS, "execution already reserved")
        if reservation.state is ReservationState.REPLAY:
            previous = reservation.outcome
            return BrokerOutcome(
                BrokerOutcomeStatus.REPLAYED,
                f"previous outcome: {previous.status}",
                previous.result,
                previous.error,
            )

        handler_arguments = validated_input.model_dump(mode="json", exclude_none=True)
        # A second round trip guarantees a fresh JSON-only copy at the side-effect boundary.
        handler_arguments = fresh_json_object(canonical_json_bytes(handler_arguments))
        try:
            result = await definition.handler(handler_arguments)
        except Exception as exc:
            outcome = BrokerOutcome(
                BrokerOutcomeStatus.FAILED, f"handler failed: {type(exc).__name__}"
            )
            await self._idempotency.complete(key, outcome)
            return outcome
        outcome = BrokerOutcome(BrokerOutcomeStatus.SUCCEEDED, "handler completed", result)
        await self._idempotency.complete(key, outcome)
        return outcome


def canary_definition(operation: str, directory: Path) -> ToolDefinition:
    async def handler(arguments: dict[str, Any]) -> dict[str, Any]:
        marker = directory / f"marker-{len(list(directory.glob('marker-*.txt')))}.txt"
        marker.write_text("canary", encoding="utf-8")
        return {"marker": marker.name}

    return ToolDefinition(operation, CanaryInput, handler)
