from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from athena_runtime.clocks import Clock, SystemClock
from athena_runtime.errors import InvalidTransition


class RunState(StrEnum):
    CREATED = "created"
    VALIDATING = "validating"
    NEEDS_CLARIFICATION = "needs_clarification"
    NEEDS_APPROVAL = "needs_approval"
    QUEUED = "queued"
    RUNNING = "running"
    QUALITY_CHECK = "quality_check"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"
    EXPIRED = "expired"
    BLOCKED = "blocked"


TERMINAL = frozenset(
    {RunState.COMPLETED, RunState.FAILED, RunState.STOPPED, RunState.EXPIRED, RunState.BLOCKED}
)
_TRANSITIONS = {
    RunState.CREATED: {RunState.VALIDATING, RunState.STOPPED, RunState.EXPIRED},
    RunState.VALIDATING: {
        RunState.NEEDS_CLARIFICATION,
        RunState.NEEDS_APPROVAL,
        RunState.QUEUED,
        RunState.FAILED,
        RunState.STOPPED,
        RunState.EXPIRED,
        RunState.BLOCKED,
    },
    RunState.NEEDS_CLARIFICATION: {RunState.VALIDATING, RunState.STOPPED, RunState.EXPIRED},
    RunState.NEEDS_APPROVAL: {
        RunState.QUEUED,
        RunState.STOPPED,
        RunState.EXPIRED,
        RunState.BLOCKED,
    },
    RunState.QUEUED: {RunState.RUNNING, RunState.STOPPED, RunState.EXPIRED, RunState.BLOCKED},
    RunState.RUNNING: {
        RunState.QUALITY_CHECK,
        RunState.FAILED,
        RunState.STOPPED,
        RunState.EXPIRED,
        RunState.BLOCKED,
    },
    RunState.QUALITY_CHECK: {
        RunState.COMPLETED,
        RunState.FAILED,
        RunState.STOPPED,
        RunState.BLOCKED,
    },
}


@dataclass(frozen=True, slots=True)
class RunTransitionEvent:
    run_id: str
    sequence: int
    from_state: RunState
    to_state: RunState
    occurred_at: datetime


class Run:
    __slots__ = ("_clock", "_events", "_run_id", "_state")

    def __init__(self, run_id: str, *, clock: Clock | None = None) -> None:
        if not run_id:
            raise ValueError("run_id must not be empty")
        self._run_id = run_id
        self._state = RunState.CREATED
        self._events: tuple[RunTransitionEvent, ...] = ()
        self._clock = clock or SystemClock()

    @classmethod
    def rehydrate(
        cls,
        run_id: str,
        state: RunState,
        events: tuple[RunTransitionEvent, ...],
        *,
        clock: Clock | None = None,
    ) -> "Run":
        run = cls(run_id, clock=clock)
        expected_state = RunState.CREATED
        for expected_sequence, event in enumerate(events, start=1):
            if event.run_id != run_id:
                raise ValueError("event run_id mismatch")
            if event.sequence != expected_sequence:
                raise ValueError("event sequence gap or duplicate")
            if event.occurred_at.tzinfo is None:
                raise ValueError("event time must be timezone-aware")
            if event.from_state is not expected_state:
                raise ValueError("event state chain mismatch")
            if event.to_state not in _TRANSITIONS.get(expected_state, set()):
                raise ValueError("event contains invalid transition")
            expected_state = event.to_state
        if expected_state is not state:
            raise ValueError("persisted final state does not match events")
        run._state = state
        run._events = tuple(events)
        return run

    @property
    def run_id(self) -> str:
        return self._run_id

    @property
    def state(self) -> RunState:
        return self._state

    @property
    def events(self) -> tuple[RunTransitionEvent, ...]:
        return self._events

    def transition(self, to_state: RunState) -> RunTransitionEvent:
        if to_state not in _TRANSITIONS.get(self._state, set()):
            raise InvalidTransition(f"invalid transition: {self._state} -> {to_state}")
        event = RunTransitionEvent(
            self._run_id,
            len(self._events) + 1,
            self._state,
            to_state,
            self._clock.now(),
        )
        self._state = to_state
        self._events += (event,)
        return event
